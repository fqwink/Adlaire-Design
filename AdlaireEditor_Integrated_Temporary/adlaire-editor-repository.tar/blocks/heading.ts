import { sanitizeInlineContent, validateInlineContent } from "./inline.js";
import type { BlockTool } from "../tools/block-tool.js";
import type { HeadingData } from "../types/public.js";

export const headingTool: BlockTool<HeadingData> = {
  type: "heading",
  kind: "block",
  create: () => ({ level: 2, text: [] }),
  normalize: (data): HeadingData => ({
    level: normalizeLevel(data.level),
    text: sanitizeInlineContent(data.text),
  }),
  validate: (data): boolean => isLevel(data.level) && validateInlineContent(data.text),
  sanitize: {},
  merge: (left, right): HeadingData => ({
    level: normalizeLevel(left.level),
    text: [
      ...sanitizeInlineContent(left.text),
      ...sanitizeInlineContent(right.text),
    ],
  }),
};

function normalizeLevel(value: unknown): HeadingData["level"] {
  return isLevel(value) ? value : 2;
}

function isLevel(value: unknown): value is HeadingData["level"] {
  return value === 1 || value === 2 || value === 3 || value === 4 || value === 5 || value === 6;
}
