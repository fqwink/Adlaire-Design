import type { BlockTool } from "../tools/block-tool.js";

export const componentTool: BlockTool = {
  type: "component",
  kind: "block",
  create: () => ({}),
  normalize: (data) => ({ ...data }),
  validate: () => true,
  sanitize: {},
};
