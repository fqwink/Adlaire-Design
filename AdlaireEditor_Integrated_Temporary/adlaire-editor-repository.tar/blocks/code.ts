import type { BlockTool } from "../tools/block-tool.js";
import type { CodeData } from "../types/public.js";

export const codeTool: BlockTool<CodeData> = {
  type: "code",
  kind: "block",
  create: () => ({ code: "" }),
  normalize: (data): CodeData => ({
    code: typeof data.code === "string" ? data.code : "",
    ...(typeof data.language === "string" && data.language.length > 0 ? { language: data.language } : {}),
  }),
  validate: (data): boolean => {
    return typeof data.code === "string" && (data.language === undefined || typeof data.language === "string");
  },
  sanitize: {},
  merge: (left, right): CodeData => ({
    code: `${typeof left.code === "string" ? left.code : ""}\n${typeof right.code === "string" ? right.code : ""}`,
    ...(typeof left.language === "string" ? { language: left.language } : {}),
  }),
};
