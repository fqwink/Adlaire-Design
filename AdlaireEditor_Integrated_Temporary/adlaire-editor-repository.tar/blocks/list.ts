import { sanitizeInlineContent, validateInlineContent } from "./inline.js";
import type { BlockTool } from "../tools/block-tool.js";
import type { ListData } from "../types/public.js";

export const listTool: BlockTool<ListData> = {
  type: "list",
  kind: "block",
  create: () => ({ style: "unordered", items: [] }),
  normalize: (data): ListData => ({
    style: normalizeStyle(data.style),
    items: normalizeItems(data.items),
  }),
  validate: (data): boolean => {
    if (!isStyle(data.style) || !Array.isArray(data.items)) {
      return false;
    }
    return data.items.every((item) => {
      if (!isRecord(item) || !validateInlineContent(item.content)) {
        return false;
      }
      return item.checked === undefined || typeof item.checked === "boolean";
    });
  },
  sanitize: {},
  merge: (left, right): ListData => ({
    style: normalizeStyle(left.style),
    items: [
      ...normalizeItems(left.items),
      ...normalizeItems(right.items),
    ],
  }),
};

function normalizeItems(value: unknown): ListData["items"] {
  if (!Array.isArray(value)) {
    return [];
  }
  return value.flatMap((item): ListData["items"] => {
    if (!isRecord(item)) {
      return [];
    }
    const checked = typeof item.checked === "boolean" ? item.checked : undefined;
    return [{
      content: sanitizeInlineContent(item.content),
      ...(checked === undefined ? {} : { checked }),
    }];
  });
}

function normalizeStyle(value: unknown): ListData["style"] {
  return isStyle(value) ? value : "unordered";
}

function isStyle(value: unknown): value is ListData["style"] {
  return value === "unordered" || value === "ordered" || value === "checklist";
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
