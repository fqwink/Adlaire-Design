import type { InlineContent, InlineMark } from "../types/public.js";

const allowedMarkTypes = new Set(["bold", "italic", "code", "strike", "link"]);

export function normalizeInlineContent(value: unknown): InlineContent[] {
  if (!Array.isArray(value)) {
    return [];
  }
  return value.flatMap((item): InlineContent[] => {
    if (!isRecord(item)) {
      return [];
    }
    if (item.type === "hard-break") {
      return [{ type: "hard-break" }];
    }
    if (item.type === "text") {
      const marks = normalizeMarks(item.marks);
      return [{
        type: "text",
        text: typeof item.text === "string" ? item.text : "",
        ...(marks === undefined ? {} : { marks }),
      }];
    }
    return [];
  });
}

export function sanitizeInlineContent(value: unknown): InlineContent[] {
  return mergeAdjacentText(normalizeInlineContent(value).map((item) => {
    if (item.type === "hard-break") {
      return item;
    }
    const marks = item.marks?.filter((mark) => mark.type !== "link" || isSafeHref(mark.href));
    return marks && marks.length > 0
      ? { ...item, marks }
      : { type: "text", text: item.text };
  }));
}

export function validateInlineContent(value: unknown): boolean {
  if (!Array.isArray(value)) {
    return false;
  }
  return value.every((item) => {
    if (!isRecord(item)) {
      return false;
    }
    if (item.type === "hard-break") {
      return true;
    }
    if (item.type !== "text" || typeof item.text !== "string") {
      return false;
    }
    if (item.marks === undefined) {
      return true;
    }
    if (!Array.isArray(item.marks)) {
      return false;
    }
    return item.marks.every(isInlineMark);
  });
}

function normalizeMarks(value: unknown): InlineMark[] | undefined {
  if (!Array.isArray(value)) {
    return undefined;
  }
  const marks = value.flatMap((item): InlineMark[] => {
    if (!isInlineMark(item)) {
      return [];
    }
    if (item.type === "link") {
      return [{
        type: "link",
        href: item.href,
        ...(item.title === undefined ? {} : { title: item.title }),
      }];
    }
    return [{ type: item.type }];
  });
  return marks.length > 0 ? marks : undefined;
}

function isInlineMark(value: unknown): value is InlineMark {
  if (!isRecord(value) || typeof value.type !== "string" || !allowedMarkTypes.has(value.type)) {
    return false;
  }
  if (value.type !== "link") {
    return true;
  }
  return typeof value.href === "string" && (value.title === undefined || typeof value.title === "string");
}

function isSafeHref(href: string): boolean {
  return href.startsWith("#")
    || href.startsWith("/")
    || href.startsWith("http://")
    || href.startsWith("https://")
    || href.startsWith("mailto:")
    || href.startsWith("tel:");
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function mergeAdjacentText(content: InlineContent[]): InlineContent[] {
  const merged: InlineContent[] = [];
  for (const item of content) {
    const previous = merged[merged.length - 1];
    if (previous?.type === "text" && item.type === "text" && sameMarks(previous.marks, item.marks)) {
      previous.text += item.text;
      continue;
    }
    merged.push(item);
  }
  return merged;
}

function sameMarks(left: unknown, right: unknown): boolean {
  return JSON.stringify(left ?? []) === JSON.stringify(right ?? []);
}
