import type { BlockTool } from "../tools/block-tool.js";
import type { UnsupportedData } from "../types/public.js";

export const unsupportedTool: BlockTool<UnsupportedData> = {
  type: "unsupported",
  kind: "block",
  create: () => ({ originalType: "unknown", originalData: {} }),
  normalize: (data): UnsupportedData => ({
    originalType: typeof data.originalType === "string" ? data.originalType : "unknown",
    originalData: isRecord(data.originalData) ? data.originalData : {},
  }),
  validate: (data): boolean => {
    return typeof data.originalType === "string" && isRecord(data.originalData);
  },
  sanitize: {},
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
