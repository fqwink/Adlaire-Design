import { ToolRegistry } from "../tools/tool.js";
import type { EditorTool } from "../types/public.js";
import { codeTool } from "./code.js";
import { headingTool } from "./heading.js";
import { listTool } from "./list.js";
import { paragraphTool } from "./paragraph.js";
import { unsupportedTool } from "./unsupported.js";

export class BlockRegistry extends ToolRegistry {
  override register(tool: EditorTool): void {
    if (tool.kind !== "block") {
      throw new Error(`Tool '${tool.type}' is not a block tool.`);
    }
    super.register(tool);
  }
}

export function createDefaultBlockRegistry(extraTools: EditorTool[] = []): BlockRegistry {
  return new BlockRegistry([
    paragraphTool,
    headingTool,
    listTool,
    codeTool,
    unsupportedTool,
    ...extraTools.filter((tool) => tool.kind === "block"),
  ]);
}
