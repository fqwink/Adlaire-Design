import { sanitizeInlineContent, validateInlineContent } from "./inline.js";
import type { BlockTool } from "../tools/block-tool.js";
import type { ParagraphData } from "../types/public.js";

export const paragraphTool: BlockTool<ParagraphData> = {
  type: "paragraph",
  kind: "block",
  create: () => ({ text: [] }),
  normalize: (data): ParagraphData => ({
    text: sanitizeInlineContent(data.text),
  }),
  validate: (data): boolean => validateInlineContent(data.text),
  sanitize: {},
  merge: (left, right): ParagraphData => ({
    text: [
      ...sanitizeInlineContent(left.text),
      ...sanitizeInlineContent(right.text),
    ],
  }),
};
