import type { ToolRegistry } from "../tools/tool.js";
import { toRecord } from "../core/record.js";
import type { EditorBlock, PasteEvent } from "../types/public.js";

export async function handlePaste(event: PasteEvent, registry: ToolRegistry): Promise<EditorBlock[]> {
  const blocks: EditorBlock[] = [];
  for (const tool of registry.list()) {
    if (tool.kind !== "block" || !tool.onPaste) {
      continue;
    }
    const data = await tool.onPaste(event);
    blocks.push({
      id: `paste-${tool.type}-${blocks.length}`,
      type: tool.type,
      data: toRecord(data),
    });
  }
  return blocks;
}
