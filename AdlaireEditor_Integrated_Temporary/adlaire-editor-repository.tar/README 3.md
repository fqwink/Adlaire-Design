# Adlaire-Editor

Adlaire-Editor is a standalone Headless WYSIWYG Editor.

The master specification is maintained in:

- [Adlaire_Editor_Master_Specification.md](./Adlaire_Editor_Master_Specification.md)

Adlaire-Editor provides editor state, editing logic, document operations, commands, validation, save requests, publish requests, and editor events.

Adlaire-Editor does not provide UI, DOM rendering, storage, network access, database access, Git operations, authentication, adapter interfaces, or integration layers.
