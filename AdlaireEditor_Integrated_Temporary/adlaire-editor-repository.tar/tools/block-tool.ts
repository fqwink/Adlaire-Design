import type { EditorTool } from "../types/public.js";

export type BlockTool<TData extends object = Record<string, unknown>> = EditorTool<TData> & {
  kind: "block";
};
