import { codeTool } from "../blocks/code.js";
import { headingTool } from "../blocks/heading.js";
import { listTool } from "../blocks/list.js";
import { paragraphTool } from "../blocks/paragraph.js";
import { unsupportedTool } from "../blocks/unsupported.js";
import type { EditorTool } from "../types/public.js";
import { createDefaultInlineTools } from "./inline.js";
import { ToolRegistry } from "./tool.js";

export function createDefaultToolRegistry(extraTools: EditorTool[] = []): ToolRegistry {
  return new ToolRegistry([
    paragraphTool,
    headingTool,
    listTool,
    codeTool,
    unsupportedTool,
    ...createDefaultInlineTools(),
    ...extraTools,
  ]);
}
