import type { EditorTool } from "../types/public.js";

export type InlineTool = EditorTool<Record<string, unknown>> & {
  kind: "inline";
};
