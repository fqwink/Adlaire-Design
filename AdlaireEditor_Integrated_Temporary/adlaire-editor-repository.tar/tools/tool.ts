import type { EditorTool } from "../types/public.js";

export class ToolRegistry {
  readonly #tools = new Map<string, EditorTool>();

  constructor(tools: EditorTool[] = []) {
    for (const tool of tools) {
      this.register(tool);
    }
  }

  register(tool: EditorTool): void {
    this.#tools.set(tool.type, tool);
  }

  get(type: string): EditorTool | undefined {
    return this.#tools.get(type);
  }

  has(type: string): boolean {
    return this.#tools.has(type);
  }

  list(): EditorTool[] {
    return [...this.#tools.values()];
  }
}
