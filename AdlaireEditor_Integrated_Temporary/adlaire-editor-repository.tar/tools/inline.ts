import type { InlineTool } from "./inline-tool.js";

export const boldTool: InlineTool = {
  type: "bold",
  kind: "inline",
  normalize: (data) => ({ ...data }),
  validate: () => true,
  sanitize: {},
};

export const italicTool: InlineTool = {
  type: "italic",
  kind: "inline",
  normalize: (data) => ({ ...data }),
  validate: () => true,
  sanitize: {},
};

export const linkTool: InlineTool = {
  type: "link",
  kind: "inline",
  normalize: (data) => ({ ...data }),
  validate: (data) => typeof data.href === "string",
  sanitize: {},
};

export const codeInlineTool: InlineTool = {
  type: "code",
  kind: "inline",
  normalize: (data) => ({ ...data }),
  validate: () => true,
  sanitize: {},
};

export const strikeTool: InlineTool = {
  type: "strike",
  kind: "inline",
  normalize: (data) => ({ ...data }),
  validate: () => true,
  sanitize: {},
};

export function createDefaultInlineTools(): InlineTool[] {
  return [boldTool, italicTool, linkTool, codeInlineTool, strikeTool];
}
