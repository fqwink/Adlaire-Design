import type { BlockRegistry } from "../blocks/registry.js";
import { mapBlocks } from "../core/block-tree.js";
import { toRecord } from "../core/record.js";
import type { EditorBlock, EditorDocument } from "../types/public.js";

export function sanitizeDocument(document: EditorDocument, registry: BlockRegistry): EditorDocument {
  return {
    ...document,
    blocks: mapBlocks(document.blocks, (block) => sanitizeBlock(block, registry)),
  };
}

export function sanitizeBlock(block: EditorBlock, registry: BlockRegistry): EditorBlock {
  const tool = registry.get(block.type);
  return {
    ...block,
    data: toRecord(tool?.normalize?.(block.data) ?? { ...block.data }),
  };
}
