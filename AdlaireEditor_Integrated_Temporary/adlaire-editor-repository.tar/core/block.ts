import type { EditorBlock } from "../types/public.js";

export function createBlock(id: string, type: string, data: Record<string, unknown>): EditorBlock {
  return { id, type, data };
}
