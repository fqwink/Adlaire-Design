import { flattenBlocks, hasDuplicateBlockIds } from "./block-tree.js";
import { editorError } from "./errors.js";
import { isValidSelection } from "./selection.js";
import type { BlockRegistry } from "../blocks/registry.js";
import type { EditorBlock, EditorDocument, EditorError, EditorSelection, EditorValidationResult } from "../types/public.js";

export function validateDocument(
  document: EditorDocument,
  registry: BlockRegistry,
  selection?: EditorSelection | null,
): EditorValidationResult {
  const base = validateDocumentStructure(document, selection);
  const errors = [...base.errors];
  const warnings = [...base.warnings];

  const blocks = isRecord(document) && Array.isArray(document.blocks) ? document.blocks : [];
  for (const block of flattenBlocks(blocks)) {
    const result = validateBlock(block, registry);
    errors.push(...result.errors);
    warnings.push(...result.warnings);
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}

export async function validateDocumentAsync(
  document: EditorDocument,
  registry: BlockRegistry,
  selection?: EditorSelection | null,
): Promise<EditorValidationResult> {
  const base = validateDocumentStructure(document, selection);
  const errors = [...base.errors];
  const warnings = [...base.warnings];

  const blocks = isRecord(document) && Array.isArray(document.blocks) ? document.blocks : [];
  for (const block of flattenBlocks(blocks)) {
    const result = await validateBlockAsync(block, registry);
    errors.push(...result.errors);
    warnings.push(...result.warnings);
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}

function validateDocumentStructure(
  document: EditorDocument,
  selection?: EditorSelection | null,
): EditorValidationResult {
  const errors: EditorError[] = [];
  const warnings: EditorError[] = [];

  if (!isRecord(document)) {
    return {
      valid: false,
      errors: [editorError("document.invalid", "Document must be an object.")],
      warnings,
    };
  }

  if (!document.id) {
    errors.push(editorError("document.id.required", "Document id is required."));
  }
  if (!document.schemaVersion) {
    errors.push(editorError("document.schemaVersion.required", "Document schemaVersion is required."));
  }
  if (!Array.isArray(document.blocks)) {
    errors.push(editorError("document.blocks.invalid", "Document blocks must be an array."));
  }
  if (Array.isArray(document.blocks) && hasDuplicateBlockIds(document.blocks)) {
    errors.push(editorError("block.id.duplicate", "Block ids must be unique within a document."));
  }

  if (selection !== undefined && !isValidSelection(document, selection)) {
    errors.push(editorError("selection.invalid", "Selection must reference valid document positions."));
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}

export function validateBlock(block: EditorBlock, registry: BlockRegistry): EditorValidationResult {
  const errors: EditorError[] = [];
  const warnings: EditorError[] = [];

  if (!block.id) {
    errors.push(editorError("block.id.required", "Block id is required.", { blockId: block.id }));
  }
  if (!block.type) {
    errors.push(editorError("block.type.required", "Block type is required.", { blockId: block.id }));
  }

  const tool = registry.get(block.type);
  if (!tool) {
    errors.push(editorError("block.type.unregistered", `Block type '${block.type}' is not registered.`, { blockId: block.id }));
    return { valid: false, errors, warnings };
  }

  if (block.type === "unsupported") {
    warnings.push(editorError("block.unsupported", "Unsupported block is retained but not editable.", { blockId: block.id }));
  }

  const valid = tool.validate ? tool.validate(block.data) : true;
  if (isPromiseLike(valid)) {
    valid.catch(() => undefined);
    errors.push(editorError("block.validation.async", `Block '${block.id}' uses async validation; call validateDocumentAsync.`, { blockId: block.id }));
    return { valid: false, errors, warnings };
  }
  if (valid !== true) {
    errors.push(editorError("block.data.invalid", `Block '${block.id}' data is invalid.`, { blockId: block.id }));
  }

  if (block.children && block.children.length > 0 && !tool.allowsChildren) {
    errors.push(editorError("block.children.notAllowed", `Block type '${block.type}' does not allow nested blocks.`, { blockId: block.id }));
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}

async function validateBlockAsync(block: EditorBlock, registry: BlockRegistry): Promise<EditorValidationResult> {
  const base = validateBlockWithoutToolData(block, registry);
  const errors = [...base.errors];
  const warnings = [...base.warnings];
  const tool = registry.get(block.type);
  if (!tool) {
    return { valid: false, errors, warnings };
  }
  const valid = tool.validate ? await tool.validate(block.data) : true;
  if (valid !== true) {
    errors.push(editorError("block.data.invalid", `Block '${block.id}' data is invalid.`, { blockId: block.id }));
  }
  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}

function validateBlockWithoutToolData(block: EditorBlock, registry: BlockRegistry): EditorValidationResult {
  const errors: EditorError[] = [];
  const warnings: EditorError[] = [];

  if (!block.id) {
    errors.push(editorError("block.id.required", "Block id is required.", { blockId: block.id }));
  }
  if (!block.type) {
    errors.push(editorError("block.type.required", "Block type is required.", { blockId: block.id }));
  }

  const tool = registry.get(block.type);
  if (!tool) {
    errors.push(editorError("block.type.unregistered", `Block type '${block.type}' is not registered.`, { blockId: block.id }));
    return { valid: false, errors, warnings };
  }

  if (block.type === "unsupported") {
    warnings.push(editorError("block.unsupported", "Unsupported block is retained but not editable.", { blockId: block.id }));
  }

  if (block.children && block.children.length > 0 && !tool.allowsChildren) {
    errors.push(editorError("block.children.notAllowed", `Block type '${block.type}' does not allow nested blocks.`, { blockId: block.id }));
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}

function isPromiseLike(value: unknown): value is Promise<unknown> {
  return typeof value === "object" && value !== null && "then" in value && typeof (value as { then?: unknown }).then === "function";
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
