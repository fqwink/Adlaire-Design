import type { EditorConfig } from "../types/public.js";

export function normalizeConfig(config: EditorConfig = {}): Required<Pick<EditorConfig, "defaultBlock" | "readOnly" | "historyLimit">> & EditorConfig {
  return {
    ...config,
    defaultBlock: config.defaultBlock ?? "paragraph",
    readOnly: config.readOnly ?? false,
    historyLimit: config.historyLimit ?? 100,
  };
}
