import type { EditorDocument } from "../types/public.js";

export function createEmptyDocument(id = "document", schemaVersion = "1.0.0"): EditorDocument {
  return {
    id,
    schemaVersion,
    blocks: [],
  };
}
