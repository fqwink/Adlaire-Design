import type { EditorBlock } from "../types/public.js";

export type BlockLocation = {
  block: EditorBlock;
  index: number;
  parent?: EditorBlock;
  siblings: EditorBlock[];
};

export function findBlock(blocks: EditorBlock[], blockId: string): BlockLocation | null {
  for (let index = 0; index < blocks.length; index += 1) {
    const block = blocks[index];
    if (!block) {
      continue;
    }
    if (block.id === blockId) {
      return { block, index, siblings: blocks };
    }
    if (block.children) {
      const child = findBlockInParent(block.children, blockId, block);
      if (child) {
        return child;
      }
    }
  }
  return null;
}

function findBlockInParent(blocks: EditorBlock[], blockId: string, parent: EditorBlock): BlockLocation | null {
  for (let index = 0; index < blocks.length; index += 1) {
    const block = blocks[index];
    if (!block) {
      continue;
    }
    if (block.id === blockId) {
      return { block, index, parent, siblings: blocks };
    }
    if (block.children) {
      const child = findBlockInParent(block.children, blockId, block);
      if (child) {
        return child;
      }
    }
  }
  return null;
}

export function mapBlocks(blocks: EditorBlock[], mapper: (block: EditorBlock) => EditorBlock): EditorBlock[] {
  return blocks.map((block) => {
    const mapped = mapper(block);
    if (!mapped.children) {
      return mapped;
    }
    return {
      ...mapped,
      children: mapBlocks(mapped.children, mapper),
    };
  });
}

export function collectBlockIds(blocks: EditorBlock[], ids = new Set<string>()): Set<string> {
  for (const block of blocks) {
    ids.add(block.id);
    if (block.children) {
      collectBlockIds(block.children, ids);
    }
  }
  return ids;
}

export function hasDuplicateBlockIds(blocks: EditorBlock[]): boolean {
  const ids = new Set<string>();
  for (const block of flattenBlocks(blocks)) {
    if (ids.has(block.id)) {
      return true;
    }
    ids.add(block.id);
  }
  return false;
}

export function flattenBlocks(blocks: EditorBlock[]): EditorBlock[] {
  const result: EditorBlock[] = [];
  for (const block of blocks) {
    result.push(block);
    if (block.children) {
      result.push(...flattenBlocks(block.children));
    }
  }
  return result;
}
