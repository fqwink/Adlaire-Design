import { findBlock } from "./block-tree.js";
import type { EditorBlock, EditorDocument, EditorPosition, EditorSelection } from "../types/public.js";

export function normalizeSelection(document: EditorDocument, selection: EditorSelection | null): EditorSelection | null {
  if (!selection) {
    return null;
  }
  const anchor = normalizePosition(document, selection.anchor);
  const focus = normalizePosition(document, selection.focus);
  if (!anchor || !focus) {
    return null;
  }
  return {
    anchor,
    focus,
    mode: selection.mode,
  };
}

export function isValidSelection(document: EditorDocument, selection: EditorSelection | null): boolean {
  if (!selection) {
    return true;
  }
  return isValidPosition(document, selection.anchor) && isValidPosition(document, selection.focus);
}

export function isValidPosition(document: EditorDocument, position: EditorPosition): boolean {
  if (!Array.isArray(document.blocks)) {
    return false;
  }
  const location = findBlock(document.blocks, position.blockId);
  if (!location) {
    return false;
  }
  if (position.path === undefined) {
    return position.offset === undefined;
  }
  if (!isValidPath(location.block, position.path)) {
    return false;
  }
  return isValidOffset(location.block, position);
}

function normalizePosition(document: EditorDocument, position: EditorPosition): EditorPosition | null {
  if (!isValidPosition(document, position)) {
    return null;
  }
  return {
    blockId: position.blockId,
    ...(position.path === undefined ? {} : { path: [...position.path] }),
    ...(position.offset === undefined ? {} : { offset: position.offset }),
  };
}

function isValidPath(block: EditorBlock, path: Array<string | number>): boolean {
  if (block.type === "paragraph" || block.type === "heading") {
    return path.length === 3 && path[0] === "text" && typeof path[1] === "number" && path[2] === "text";
  }
  if (block.type === "list") {
    return path.length === 5
      && path[0] === "items"
      && typeof path[1] === "number"
      && path[2] === "content"
      && typeof path[3] === "number"
      && path[4] === "text";
  }
  if (block.type === "code") {
    return path.length === 1 && path[0] === "code";
  }
  return false;
}

function isValidOffset(block: EditorBlock, position: EditorPosition): boolean {
  if (position.offset === undefined) {
    return true;
  }
  const target = getTextAtPath(block, position.path ?? []);
  return typeof target === "string" && position.offset >= 0 && position.offset <= target.length;
}

function getTextAtPath(block: EditorBlock, path: Array<string | number>): string | null {
  let current: unknown = block.data;
  for (const part of path) {
    if (typeof part === "number") {
      if (!Array.isArray(current)) {
        return null;
      }
      current = current[part];
      continue;
    }
    if (!isRecord(current)) {
      return null;
    }
    current = current[part];
  }
  return typeof current === "string" ? current : null;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
