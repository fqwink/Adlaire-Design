import { cloneJson } from "./clone.js";
import type { EditorDocument, EditorSelection, HistoryEntry } from "../types/public.js";

export class History {
  readonly #undoStack: HistoryEntry[] = [];
  readonly #redoStack: HistoryEntry[] = [];
  readonly #limit: number;

  constructor(limit = 100) {
    this.#limit = Math.max(0, limit);
  }

  get canUndo(): boolean {
    return this.#undoStack.length > 0;
  }

  get canRedo(): boolean {
    return this.#redoStack.length > 0;
  }

  push(entry: HistoryEntry): void {
    if (this.#limit === 0) {
      return;
    }
    this.#undoStack.push(cloneJson(entry));
    while (this.#undoStack.length > this.#limit) {
      this.#undoStack.shift();
    }
    this.#redoStack.length = 0;
  }

  undo(currentDocument: EditorDocument, currentSelection: EditorSelection | null): HistoryEntry | null {
    const entry = this.#undoStack.pop();
    if (!entry) {
      return null;
    }
    this.#redoStack.push({
      before: {
        document: cloneJson(entry.before.document),
        selection: cloneJson(entry.before.selection),
      },
      after: {
        document: cloneJson(currentDocument),
        selection: cloneJson(currentSelection),
      },
      commands: cloneJson(entry.commands),
    });
    return cloneJson(entry);
  }

  redo(): HistoryEntry | null {
    const entry = this.#redoStack.pop();
    if (!entry) {
      return null;
    }
    this.#undoStack.push(cloneJson(entry));
    return cloneJson(entry);
  }
}
