import type { EditorError } from "../types/public.js";

export function editorError(
  code: string,
  message: string,
  details: Pick<EditorError, "blockId" | "path"> = {},
): EditorError {
  return {
    code,
    message,
    ...details,
  };
}
