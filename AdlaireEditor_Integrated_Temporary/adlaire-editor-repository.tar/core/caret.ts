import { flattenBlocks } from "./block-tree.js";
import type { EditorDocument, EditorPosition } from "../types/public.js";

export function getFirstBlockPosition(document: EditorDocument): EditorPosition | null {
  const first = flattenBlocks(document.blocks)[0];
  return first ? { blockId: first.id } : null;
}

export function getLastBlockPosition(document: EditorDocument): EditorPosition | null {
  const blocks = flattenBlocks(document.blocks);
  const last = blocks[blocks.length - 1];
  return last ? { blockId: last.id } : null;
}

export function getNextBlockPosition(document: EditorDocument, blockId: string): EditorPosition | null {
  const blocks = flattenBlocks(document.blocks);
  const index = blocks.findIndex((block) => block.id === blockId);
  const next = index >= 0 ? blocks[index + 1] : undefined;
  return next ? { blockId: next.id } : null;
}

export function getPreviousBlockPosition(document: EditorDocument, blockId: string): EditorPosition | null {
  const blocks = flattenBlocks(document.blocks);
  const index = blocks.findIndex((block) => block.id === blockId);
  const previous = index > 0 ? blocks[index - 1] : undefined;
  return previous ? { blockId: previous.id } : null;
}
