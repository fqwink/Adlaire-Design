import type { BlockRegistry } from "../blocks/registry.js";
import { validateDocument } from "../core/validation.js";
import { sanitizeDocument } from "../sanitizer/sanitize.js";
import { normalizeDocument } from "../transforms/normalize.js";
import type { EditorDocument, PublishContext, PublishRequest } from "../types/public.js";

export function createPublishRequest(
  document: EditorDocument,
  registry: BlockRegistry,
  context: PublishContext = { reason: "manual" },
): PublishRequest {
  const normalized = normalizeDocument(document, registry);
  const sanitized = sanitizeDocument(normalized, registry);
  return {
    document: sanitized,
    context,
    validation: validateDocument(sanitized, registry),
  };
}
