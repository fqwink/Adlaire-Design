# Adlaire-Editor Master Specification

## 0. 仕様ステータス

本ファイルを Adlaire-Editor のマスター仕様とする。
Adlaire-Editor の設計、実装、レビュー、破壊的変更判断は本ファイルを正とする。

**確定事項：**
- Adlaire-Editor は UI を持たない Headless WYSIWYG Editor である
- Adlaire-Editor は EditorDocument を内部文書形式の正本とする
- Adlaire-Editor は block-based architecture を採用する
- Adlaire-Editor は Editor.js 本体、Editor.js plugin ecosystem、外部 editor framework を採用しない
- Adlaire-Editor は adapter interface、integration layer、storage、network、database、Git、auth を提供しない
- Adlaire-Editor は外部プロジェクト固有仕様を持たない

**変更ルール：**
- 本章の確定事項を変更する場合はマスター仕様の破壊的変更として扱う
- Public Editor API、EditorDocument schema、EditorCommand、EditorEvent の互換性を壊す変更は破壊的変更として扱う
- UI、storage、adapter、外部プロジェクト統合を本体責務へ戻す変更は禁止する

## 1. 基本決定

**Adlaire-Editor** は、UI を持たない **Headless WYSIWYG Editor** として独立プロジェクトで開発する。
Adlaire-Editor は editor state、editing logic、document operation を提供する。
Adlaire-Editor は画面、DOM、toolbar、menu、panel、modal、CSS、UI component を提供しない。

Adlaire-Editor は Editor.js / Notion 型の編集体験にインスパイアされた **block-based architecture** を採用する。
ただし、Editor.js 本体、Editor.js plugin ecosystem、外部 editor framework は採用しない。

Adlaire-Editor は UI を提供しない。
UI 実装は本仕様の対象外とする。
Adlaire-Design の Editor UI は、外部 UI 実装が参照できる設計仕様であり、Adlaire-Editor 本体仕様には含めない。

## 2. スコープ

**Adlaire-Editor が提供するもの：**
- headless editor
- document state
- block model
- block registry
- EditorDocument loader
- EditorDocument saver
- tool registry
- block tool interface
- inline tool interface
- paste handling
- sanitizer
- caret model
- selection model
- command model
- event bus
- read-only mode
- history / undo / redo
- transform pipeline
- validation hooks

**Adlaire-Editor の正本：**
- EditorDocument
- EditorBlock
- EditorSelection
- EditorCommand
- EditorTool
- EditorEvent

Adlaire-Editor は上記の editor state と editor logic を正本として扱う。
Markdown / MDX / JSON / HTML / database record / file path は正本にしない。

**Adlaire-Editor が提供しないもの：**
- Editor UI
- toolbar UI
- inline toolbar UI
- toolbox UI
- menu UI
- panel UI
- modal UI
- DOM rendering
- CSS / theme
- icon set
- placeholder UI
- autofocus UI
- i18n UI dictionary
- Adlaire-Design component implementation
- Markdown / MDX / JSON の最終保存実装
- Git commit / Git Sync
- parser / serializer adapter interface
- save / publish adapter interface
- UI adapter interface
- integration layer
- database persistence
- file-backed draft persistence
- user account system
- collaboration server

## 3. 責務分離

| 領域 | 責務 |
|---|---|
| Adlaire-Editor | headless editor、Editor.js 相当の logic features、EditorDocument loader、EditorDocument saver、tool registry、block model、selection、history、command |
| Adlaire-Design | Editor UI、UI token、component、layout、interaction pattern |
| 利用プロジェクト | 外部形式変換、保存、公開、UI実装、route、auth、asset handling |

Adlaire-Editor は Adlaire-Design に直接依存しない。
Adlaire-Design は外部 UI 実装の設計仕様として参照できる。
Adlaire-Editor 本体は Adlaire-Design の UI component、CSS、token、runtime を import しない。

## 3.1 External Boundary

Adlaire-Editor は Adlaire-Design、保存先、公開先、外部プロジェクトに依存しない。
Adlaire-Editor は接続層を提供しない。
Adlaire-Editor は adapter interface を提供しない。

| 項目 | Adlaire-Editor | 外部 |
|---|---|---|
| 所有範囲 | editor document / block / tool / selection / caret / command / history / save lifecycle / publish request lifecycle | content source / route / preview / publish execution / storage / UI |
| UI | 持たない | 外部で実装する |
| 保存 | save lifecycle までを扱う | 実際の保存先を実装する |
| 公開 | publish request lifecycle までを扱う | 実際の公開処理を実装する |
| 外部形式 | EditorDocumentのみを扱う | Markdown / MDX / JSON 等へ変換する |
| Git | 依存しない | 必要なら外部で実装する |
| Database | 依存しない | 必要なら外部で実装する |
| 公開API | headless editor API / EditorDocument | なし |

Adlaire-Editor は以下を import / call してはならない。
- 外部プロジェクトの content collection
- 外部プロジェクトの sync / storage / database gateway
- 外部プロジェクトの route / server runtime
- 外部プロジェクトの config
- Adlaire-Design component implementation
- DOM API
- CSS / stylesheet
- UI framework runtime

Adlaire-Editor が外部へ提供するのは headless editor API と EditorDocument model のみとする。

## 3.2 Runtime / Package Boundary

Adlaire-Editor は TypeScript first の headless package として実装する。
runtime 固有 API へ依存してはならない。

**許可：**
- TypeScript
- ECMAScript standard API
- pure function
- immutable data operation
- structured error
- typed public API

**禁止：**
- DOM API
- Browser API 固定
- Node.js API 固定
- Deno API 固定
- filesystem
- database driver
- fetch / network request
- UI framework runtime
- CSS import
- image / asset processing engine

Adlaire-Editor は browser、server、test runner のいずれでも同じ editor logic を実行できることを前提とする。

## 4. Core Model

```ts
interface EditorDocument {
  id: string;
  schemaVersion: string;
  blocks: EditorBlock[];
  meta?: Record<string, unknown>;
}

interface EditorBlock {
  id: string;
  type: string;
  data: Record<string, unknown>;
  children?: EditorBlock[];
  meta?: EditorBlockMeta;
}

interface EditorBlockMeta {
  locked?: boolean;
  validationState?: "valid" | "invalid" | "warning";
  sourceRange?: SourceRange;
  createdAt?: string;
  updatedAt?: string;
}

interface SourceRange {
  start: number;
  end: number;
}
```

**Core model policy：**
- `EditorDocument` はエディタ内部の唯一の文書形式とする
- `EditorBlock.id` は document 内で一意とする
- `EditorBlock.type` は tool registry に登録された type と一致させる
- `EditorBlock.data` は block type ごとの schema で検証する
- `children` は nested block を許可する block type のみ使用できる
- `meta` は編集補助情報であり、外部保存形式への出力を保証しない
- block の並び順は `blocks` 配列順を正とする

## 4.1 Public Editor API

Adlaire-Editor は UI を持たないため、外部 UI は Public Editor API を通して editor state を操作する。
Public Editor API は DOM、framework、storage、network に依存してはならない。

```ts
interface EditorController {
  getDocument(): EditorDocument;
  setDocument(document: EditorDocument): void;
  dispatch(command: EditorCommand): EditorCommandResult;
  dispatchBatch(commands: EditorCommand[]): EditorCommandResult;
  canDispatch(command: EditorCommand): boolean;
  getSelection(): EditorSelection | null;
  setSelection(selection: EditorSelection | null): void;
  undo(): EditorCommandResult;
  redo(): EditorCommandResult;
  save(context?: SaveContext): SaveRequest;
  requestPublish(context?: PublishContext): PublishRequest;
  subscribe(listener: EditorEventListener): Unsubscribe;
}

interface EditorCommandResult {
  document: EditorDocument;
  selection?: EditorSelection | null;
  changed: boolean;
  errors?: EditorError[];
}
```

Public Editor API は adapter interface ではない。
外部 UI はこの API を直接利用する。

`dispatchBatch()` は複数 command を一つの history entry として扱う Public Editor API とする。
Batch 内のいずれかの command が失敗した場合、document と selection は batch 実行前の state から変更してはならない。
`save` と `request-publish` は batch command に含めてはならない。
Selection-only batch は document dirty state を変更せず、document change event を発火しない。

## 4.2 Selection Model

```ts
interface EditorSelection {
  anchor: EditorPosition;
  focus: EditorPosition;
  mode: "caret" | "range" | "block";
}

interface EditorPosition {
  blockId: string;
  path?: Array<string | number>;
  offset?: number;
}
```

Selection は DOM selection ではなく、EditorDocument に対する論理 selection とする。
DOM selection への変換は外部 UI の責務とする。

## 4.3 Configuration Model

```ts
interface EditorConfig {
  document?: EditorDocument;
  tools?: EditorTool[];
  defaultBlock?: string;
  readOnly?: boolean;
  historyLimit?: number;
  sanitizer?: SanitizerRules;
}
```

**Configuration policy：**
- config は editor logic の初期化に限定する
- config に DOM element、selector、CSS class、route、storage path、URL を含めない
- `defaultBlock` は tool registry に存在する block type とする
- `tools` は block / inline behavior の登録に限定する
- UI 表示名、icon、shortcut 表示は Adlaire-Editor 本体の必須設定にしない

## 4.4 Lifecycle

Adlaire-Editor は UI lifecycle ではなく editor lifecycle を持つ。

**Lifecycle：**
- create controller
- load document
- normalize document
- register tools
- validate document
- dispatch command
- emit event
- create save request
- create publish request
- destroy controller

destroy は listener と internal state を解放する。
destroy は storage、network、DOM cleanup を実行しない。

## 5. Editor.js-inspired Logic Features

Adlaire-Editor は Editor.js の logic features と同等の責務を持つ。
これは Editor.js API 互換を意味しない。
Adlaire-Editor は Editor.js の設計思想を参照し、UI を持たない headless editor として同種の編集ロジックを提供する。

**必須 logic features：**
- blocks：block 作成、挿入、削除、移動、取得、件数取得、clear、render state
- tools：block tool / inline tool の登録、設定、read-only 対応、lifecycle
- saver：EditorDocument / EditorBlock data の収集、validate、sanitize、save lifecycle
- sanitizer：block / inline data の sanitize rule 適用
- caret：先頭 block、末尾 block、前後 block、指定 block への caret 移動
- selection：現在選択、block selection、range selection
- events：editor event の subscribe / unsubscribe / emit
- listeners：外部 subscriber が利用する event listener lifecycle
- command：編集操作の実行、batching、undo / redo 接続
- history：command history、undo、redo
- readOnly：編集不可状態の切り替え
- paste：HTML、plain text、file、URL paste の hook

**禁止：**
- Editor.js 本体を採用しない
- Editor.js API 互換を保証しない
- DOM 前提の Tool 実装を Adlaire-Editor 本体へ入れない
- toolbar / inline toolbar UI を Adlaire-Editor 本体へ入れない

## 6. Block-based Architecture

Adlaire-Editor は文章を block 配列として扱う。
block は document state の最小編集単位とする。

**標準 block type：**
- `paragraph`
- `heading`
- `list`
- `quote`
- `code`
- `image`
- `divider`
- `table`
- `callout`
- `component`

`component` block は外部プロジェクトが解釈する。

**Block policy：**
- block は immutable update を前提に更新する
- block type ごとに data schema、normalize、validate、sanitize を持つ
- block type が未登録の場合、document load 時に `unsupported` block として保持できる
- unsupported block は data を破棄せず、編集不可 block として扱う
- block の drag / reorder は command として扱う
- inline formatting は inline tool として扱い、block data 内に正規化する

**初期 inline tool：**
- `bold`
- `italic`
- `link`
- `code`
- `strike`

**MVP block type：**
- `paragraph`
- `heading`
- `list`
- `code`
- `unsupported`

標準 block type は段階的に実装できる。
MVP は上記の MVP block type を必須とする。

## 6.1 Block Data Shape

MVP block type の data shape は以下を初期仕様とする。

```ts
interface ParagraphData {
  text: InlineContent[];
}

interface HeadingData {
  level: 1 | 2 | 3 | 4 | 5 | 6;
  text: InlineContent[];
}

interface ListData {
  style: "unordered" | "ordered" | "checklist";
  items: Array<{ content: InlineContent[]; checked?: boolean }>;
}

interface CodeData {
  code: string;
  language?: string;
}

interface UnsupportedData {
  originalType: string;
  originalData: Record<string, unknown>;
}

type InlineContent =
  | { type: "text"; text: string; marks?: InlineMark[] }
  | { type: "hard-break" };

type InlineMark =
  | { type: "bold" }
  | { type: "italic" }
  | { type: "code" }
  | { type: "strike" }
  | { type: "link"; href: string; title?: string };
```

InlineContent は DOM や HTML fragment ではなく、EditorDocument 内の構造化 inline data とする。

## 6.1.1 Unsupported Block Behavior

`unsupported` block は未登録または未対応の block type を保持するための fallback block とする。
Unsupported block は data loss を防ぐことを最優先とする。

**Unsupported block policy：**
- load / normalize 時に未登録 block type を `unsupported` block として保持できる
- `UnsupportedData.originalType` には元の block type を保存する
- `UnsupportedData.originalData` には元の block data を破棄せず保存する
- unsupported block の `data` は通常の `update-block` で編集してはならない
- unsupported block の move / delete / selection は許可する
- unsupported block の split / merge は拒否する
- unsupported block を別 type へ convert する場合は明示 command または tool behavior を必要とする
- unsupported block の validation は warning として扱い、document 全体を invalid にしない

Unsupported block の存在は publish 前 validation warning に含めることができる。
外部 UI は warning を表示できるが、Adlaire-Editor 本体は UI 表示を提供しない。

## 6.2 Block Tunes

Adlaire-Editor は Editor.js の Block Tunes に相当する headless block metadata を持つ。
Block Tunes は UI menu ではなく、block に付与する編集補助 metadata として扱う。

```ts
interface BlockTune {
  type: string;
  data: Record<string, unknown>;
}
```

**Block Tunes policy：**
- Block Tunes は `EditorBlock.meta` または block data 内に正規化する
- Block Tunes は toolbar、menu、popover を提供しない
- Block Tunes の validation / sanitize は tool 側が定義する
- MVP では Block Tunes UI を持たない

## 7. Tool Model

Adlaire-Editor は Editor.js の Tool 概念に相当する **Tool Model** を持つ。
Tool は UI 実装ではなく、block / inline behavior の定義として扱う。

```ts
interface EditorTool<TData = Record<string, unknown>> {
  type: string;
  kind: "block" | "inline";
  create?(context: ToolContext): TData;
  normalize?(data: TData): TData;
  validate?(data: TData): boolean | Promise<boolean>;
  sanitize?: SanitizerRules;
  merge?(left: TData, right: TData): TData;
  convert?(data: TData, targetType: string): Record<string, unknown>;
  onPaste?(event: PasteEvent): TData | Promise<TData>;
}

interface ToolContext {
  api: EditorApi;
  readOnly: boolean;
  config?: Record<string, unknown>;
}

interface EditorApi {
  getDocument(): EditorDocument;
  getSelection(): EditorSelection | null;
  dispatch(command: EditorCommand): EditorCommandResult;
}

interface PasteEvent {
  type: "html" | "text" | "file" | "url";
  data: unknown;
}

type SanitizerRules = Record<string, unknown>;
```

Tool は DOM を返してはならない。
UI は外部で実装する。
外部 UI は必要に応じて Adlaire-Design Editor UI を参照できる。

**Tool lifecycle：**
- `create`
- `normalize`
- `validate`
- `sanitize`
- `merge`
- `convert`
- `onPaste`

Tool は editor state を直接変更してはならない。
Tool が編集を必要とする場合は command を返すか、Public Editor API へ command を dispatch する。

## 7.1 Tool Metadata

Tool metadata は headless metadata として扱う。
UI 表示は外部 UI の責務とする。

```ts
interface ToolMetadata {
  type: string;
  kind: "block" | "inline";
  title?: string;
  category?: string;
  shortcut?: string;
}
```

Tool metadata は UI component、icon component、render function を含めてはならない。

## 7.2 Default Tool Registry

MVP 実装は default tool registry を提供する。
Default tool registry は以下を含む。

- default block registry
- `bold`
- `italic`
- `link`
- `code`
- `strike`

Default inline tool は inline mark / inline node の behavior のみを定義し、UI 表示要素を含めてはならない。
`createDefaultToolRegistry()` は default block registry と default inline tools を合成した registry を返す。

## 8. Command Model

編集操作は command として扱う。
command は document state を直接破壊せず、新しい state を返す。

```ts
interface EditorCommand<TPayload = unknown> {
  type: string;
  payload: TPayload;
}

interface CommandHandler<TPayload = unknown> {
  apply(document: EditorDocument, payload: TPayload): EditorDocument;
  undo?(document: EditorDocument, payload: TPayload): EditorDocument;
}
```

**標準 command：**
- `insert-block`
- `delete-block`
- `move-block`
- `update-block`
- `split-block`
- `merge-block`
- `set-selection`
- `set-document-meta`
- `save`
- `request-publish`

**Command policy：**
- command は editor state 変更の唯一の入口とする
- command は原則として pure function として実装する
- command handler は DOM、storage、network を呼び出してはならない
- undo / redo は command history に基づく
- 複数 command を一つの history entry として batch 化できる

## 8.1 Standard Command Payload

MVP の標準 command payload は以下を正とする。
Payload は serializable data のみを含める。
Function、class instance、DOM node、外部 resource handle を含めてはならない。

```ts
type InsertBlockPayload = {
  block: EditorBlock;
  index?: number;
  parentBlockId?: string;
  select?: boolean;
};

type DeleteBlockPayload = {
  blockId: string;
};

type MoveBlockPayload = {
  blockId: string;
  toIndex: number;
  fromParentBlockId?: string;
  toParentBlockId?: string;
};

type UpdateBlockPayload = {
  blockId: string;
  data?: Record<string, unknown>;
  meta?: EditorBlockMeta;
};

type SplitBlockPayload = {
  blockId: string;
  position: EditorPosition;
};

type MergeBlockPayload = {
  sourceBlockId: string;
  targetBlockId: string;
};

type SetSelectionPayload = {
  selection: EditorSelection | null;
};

type SetDocumentMetaPayload = {
  meta: Record<string, unknown>;
  merge?: boolean;
};

type SaveCommandPayload = {
  context?: SaveContext;
};

type RequestPublishCommandPayload = {
  context?: PublishContext;
};
```

**Payload policy：**
- `insert-block.index` 省略時は対象 block 配列の末尾へ挿入する
- `parentBlockId` 指定時は nested block 挿入として扱う
- nested block を許可しない block type への挿入は validation error とする
- `delete-block` は対象 block とその children を削除する
- `move-block` は同一 parent 内、または nested block を許可する parent 間でのみ成功する
- `update-block.data` は既存 data 全体を置換する
- `update-block.meta` は既存 meta と shallow merge する
- `split-block` / `merge-block` は block tool の schema と merge behavior に従う
- `set-selection` は selection state のみ変更し、document dirty state を変更しない
- `save` と `request-publish` は Public Editor API の `save()` / `requestPublish()` と同じ lifecycle を呼ぶ
- `save.context` 省略時は `{ reason: "manual" }` として扱う
- `request-publish.context` 省略時は `{ reason: "manual" }` として扱う
- `move-block.fromParentBlockId` が指定され、実際の parent と一致しない場合は payload error とする
- `split-block.position` は対象 block type が定義する editable path のみを許可する
- `split-block` の offset は対象 text / code の UTF-16 code unit 範囲内の整数とする
- `split-block` で生成される block id が既存 block id と衝突する場合は payload error とする
- `merge-block` は `sourceBlockId` と `targetBlockId` が同一の場合は payload error とする
- `merge-block` は原則として同一 block type 間のみ成功し、異種 block の merge は block tool が明示的に許可する場合だけ成功する

## 8.2 Command Error Policy

Command error は例外ではなく `EditorCommandResult.errors` の structured error として返す。
Command が失敗した場合、document と selection は command 実行前の state から変更してはならない。

**標準 error code：**
- `command.invalid`
- `command.unknown`
- `command.payload.invalid`
- `command.readonly`
- `command.batch.invalid`

`canDispatch()` は unknown command、malformed command、read-only で拒否される mutation command に対して `false` を返す。
`dispatch()` と `dispatchBatch()` は失敗時に `changed: false` を返し、history entry を作らない。

## 9. Selection / Caret / History

Selection は UI から独立した headless state として扱う。
History は command 単位で管理する。

**必須機能：**
- current selection
- block selection
- cursor position
- undo
- redo
- command batching
- caret movement
- read-only guard

**History policy：**
- history は document change と selection change を記録できる
- read-only mode では document change command を拒否する
- selection-only command は document dirty state を変更しない
- undo / redo は save / publish の実行結果を巻き戻さない
- history size の上限は実装設定で変更可能とする

## 9.1 Selection Path Semantics

`EditorPosition.path` は block data 内の論理位置を表す。
Path は JSON Pointer ではなく、Adlaire-Editor 固有の structured path とする。

**MVP path 規約：**
- paragraph / heading の本文は `["text", index, "text"]`
- list item の本文は `["items", itemIndex, "content", inlineIndex, "text"]`
- code block の本文は `["code"]`
- block 全体を指す場合は `path` と `offset` を省略できる
- inline content の `offset` は UTF-16 code unit offset とする
- `hard-break` は caret offset を持たない atomic inline node として扱う
- unknown path は validation error とし、暗黙に補正しない

Selection は常に current document に存在する block id を参照する。
参照先 block が command により削除された場合、controller は selection を `null` にするか、直近の有効 block へ normalize する。
どちらの挙動を採用するかは実装で固定し、test で保証する。

## 9.2 History Implementation Policy

MVP の history は document snapshot 方式を採用する。
各 history entry は command 実行前後の `EditorDocument` と `EditorSelection | null` を保持する。

```ts
interface HistoryEntry {
  before: {
    document: EditorDocument;
    selection: EditorSelection | null;
  };
  after: {
    document: EditorDocument;
    selection: EditorSelection | null;
  };
  commands: EditorCommand[];
}
```

**History implementation policy：**
- undo は `before` state へ戻す
- redo は `after` state へ戻す
- command handler の `undo()` は将来の差分方式拡張用であり、MVP では必須にしない
- changed が `false` の command は history entry を作らない
- selection-only command は history に記録できるが dirty state を変更しない
- selection が実行前と同一の場合、selection-only command は no-op として `changed: false` を返す
- selection-only command と selection-only batch は document change event を発火しない
- selection-only history entry の undo / redo は document dirty state を変更しない
- save / publish request は history entry を作らない
- new command 実行時は redo stack を破棄する
- history limit 超過時は最古の entry から破棄する

## 9.3 Read-only Behavior

read-only mode は document mutation を防ぐ。
UI 操作の禁止ではなく、Public Editor API と command dispatch の guard として実装する。

**read-only で拒否するもの：**
- `insert-block`
- `delete-block`
- `move-block`
- `update-block`
- `split-block`
- `merge-block`
- `set-document-meta`
- document を変更する custom command

**read-only で許可するもの：**
- `getDocument`
- `getSelection`
- `setSelection`
- `canDispatch`
- `save`
- `requestPublish`
- `subscribe`
- validation

read-only で拒否された command は document を変更せず、`changed: false` と structured error を返す。
拒否された command は history に記録しない。

## 10. Saver / Save Lifecycle

Adlaire-Editor は保存機能を持つ。
ただし、保存先には依存しない。

Adlaire-Editor が持つのは save command、dirty state、saving state、save error state、autosave trigger、save lifecycle である。
実際の保存先は外部プロジェクトが実装する。

```ts
interface SaveContext {
  reason: "manual" | "autosave" | "before-publish";
  baseVersion?: string;
}

interface SaveState {
  dirty: boolean;
  saving: boolean;
  lastRequestedAt?: string;
  error?: string;
}

interface SaveRequest {
  document: EditorDocument;
  context: SaveContext;
  state: SaveState;
}
```

Save lifecycle は保存要求を作るまでを責務とする。
保存先への書き込み、保存結果の確定、conflict 解決は外部プロジェクトの責務とする。

## 11. Publish Request Lifecycle

Adlaire-Editor は publish request lifecycle を持つ。
ただし、公開処理の実体は持たない。

Adlaire-Editor は publish command、publish requested state、publish disabled state、publish validation state、publish error state を管理する。
実際の publish は外部が実装する。

```ts
interface PublishContext {
  reason: "manual" | "after-save";
}

interface PublishRequest {
  document: EditorDocument;
  context: PublishContext;
  validation: EditorValidationResult;
}
```

Publish request lifecycle は公開要求を作るまでを責務とする。
公開先への反映、build trigger、deployment、公開履歴の永続化は外部プロジェクトの責務とする。

## 11.1 Validation / Error Model

```ts
interface EditorValidationResult {
  valid: boolean;
  errors: EditorError[];
  warnings: EditorError[];
}

interface EditorError {
  code: string;
  message: string;
  blockId?: string;
  path?: Array<string | number>;
}
```

**Validation policy：**
- document validation は publish request 前に必ず実行する
- block validation は block update 時に実行できる
- sanitizer は保存要求前に実行できる
- validation error は外部 UI が表示できる構造化エラーとして返す
- error message は内部例外をそのまま露出しない
- malformed document は例外ではなく `document.invalid` または `document.blocks.invalid` の structured error として返す

## 11.1.1 Normalize / Sanitize / Validate Order

EditorDocument に対する処理順序は以下を標準とする。

1. normalize
2. sanitize
3. validate

**Lifecycle 別の必須処理：**
- `setDocument` は normalize と validate を実行する
- `dispatch` は command apply 後に対象 block を normalize し、必要に応じて validate する
- `save` は document 全体を normalize、sanitize、validate した上で `SaveRequest` を返す
- `requestPublish` は document 全体を normalize、sanitize、validate した上で `PublishRequest` を返す

normalize は欠落した optional field の補完、unsupported block への変換、block data shape の正規化を行う。
sanitize は危険または許可されない data を削除または正規化する。
validate は document を変更せず、構造化された validation result を返す。

sanitize により data が変更された場合、その変更は返却される `SaveRequest.document` または `PublishRequest.document` に反映する。
ただし controller 内の current document を更新するかどうかは実装で固定し、event と dirty state の挙動を test で保証する。

## 11.1.2 Async Validation

Synchronous validation は asynchronous block validation を実行しない。
Asynchronous validation が必要な block に対して sync validation が呼ばれた場合、`block.validation.async` warning または error を返す。

`validateDocumentAsync()` は asynchronous block validation を await し、sync validation と同じ `EditorValidationResult` shape を返す。
Public API 利用者は publish 前検証で async validation が必要な tool を含む場合、`validateDocumentAsync()` を使用する。

## 11.2 Event Model

```ts
type EditorEvent =
  | { type: "document:changed"; document: EditorDocument }
  | { type: "selection:changed"; selection: EditorSelection | null }
  | { type: "history:changed"; canUndo: boolean; canRedo: boolean }
  | { type: "save:requested"; request: SaveRequest }
  | { type: "publish:requested"; request: PublishRequest }
  | { type: "error"; error: EditorError };

type EditorEventListener = (event: EditorEvent) => void;
type Unsubscribe = () => void;
```

Event は UI 通知と外部処理の起点として扱う。
Event は storage / network の実行契約ではない。

## 12. External Format Policy

Adlaire-Editor は内部文書形式として EditorDocument を扱う。
Adlaire-Editor は Markdown / MDX / JSON 等の外部形式を直接扱わない。

**外部形式方針：**
- Adlaire-Editor の入出力境界は EditorDocument とする
- Markdown / MDX / JSON parser は Adlaire-Editor 本体へ入れない
- Markdown / MDX / JSON serializer は Adlaire-Editor 本体へ入れない
- parser / serializer adapter interface も Adlaire-Editor 本体へ入れない
- save / publish adapter interface も Adlaire-Editor 本体へ入れない
- UI adapter interface も Adlaire-Editor 本体へ入れない
- 外部形式との変換は利用プロジェクトが Adlaire-Editor の外側で実装する

## 12.1 Security Policy

Adlaire-Editor は UI、storage、network を持たないため、実行系の security policy は外部プロジェクトが担当する。
Adlaire-Editor 本体は editor data の安全性を保つため、以下を必須とする。

- sanitizer により block data を正規化できる
- validation error は構造化して返す
- HTML string を信頼済み出力として扱わない
- script execution を行わない
- URL validation は link mark / embed-like block の validation として実装できる
- raw HTML block は標準 block type に含めない

## 13. Storage Policy

Adlaire-Editor は永続化を担当しない。

**禁止：**
- database driver 依存
- file system 依存
- Git 依存
- browser storage 固定
- network API 固定

永続化は利用プロジェクトが Adlaire-Editor の外側で担当する。

## 14. UI Policy

Adlaire-Editor は UI を持たない。
Adlaire-Editor は Headless WYSIWYG Editor であり、UI を本体責務に含めない。
Adlaire-Design Editor UI は外部 UI 実装が参照できる設計仕様である。

Adlaire-Editor は Adlaire-Design の内部 component 実装に依存しない。
Adlaire-Design との接続方法は Adlaire-Editor 本体仕様には含めない。
Adlaire-Editor は UI adapter interface を提供しない。
外部 UI は headless editor API と EditorDocument model を直接利用する。

**UIとして提供しないもの：**
- editor shell
- toolbar
- inline toolbar
- toolbox
- block menu
- block tune menu
- slash menu
- context menu
- modal
- panel
- drag handle
- block hover UI
- placeholder rendering
- focus ring
- keyboard shortcut display
- localization dictionary for UI text

**Headlessとして提供するもの：**
- editor state
- document operation
- selection / caret state
- command dispatch
- history state
- validation result
- save request
- publish request
- editor event

## 15. Project Structure

```text
Adlaire-Editor/
├── mod.ts
├── core/
│   ├── document.ts
│   ├── block.ts
│   ├── selection.ts
│   ├── config.ts
│   ├── validation.ts
│   └── history.ts
├── blocks/
│   ├── registry.ts
│   ├── paragraph.ts
│   ├── heading.ts
│   ├── list.ts
│   ├── code.ts
│   ├── unsupported.ts
│   └── component.ts
├── tools/
│   ├── tool.ts
│   ├── block-tool.ts
│   └── inline-tool.ts
├── commands/
│   ├── command.ts
│   ├── insert-block.ts
│   ├── delete-block.ts
│   └── update-block.ts
├── saver/
│   └── save.ts
├── publisher/
│   └── publish.ts
├── sanitizer/
│   └── sanitize.ts
├── events/
│   └── event-bus.ts
├── lifecycle/
│   └── controller.ts
├── transforms/
│   └── normalize.ts
└── types/
	    └── public.ts
```

## 15.1 Package / Runtime Policy

Adlaire-Editor は TypeScript package として実装する。
Package は editor logic の配布単位であり、application runtime ではない。

**Package policy：**
- source は TypeScript とする
- public entrypoint は `mod.ts` とする
- public type は `types/public.ts` から export する
- DOM、Browser、Node.js、Deno 固有 API を public API に含めない
- npm package として利用できる module output を提供する
- ESM を primary output とする
- CommonJS output は必須にしない
- test runner は DOM environment を必須にしない
- package metadata に UI framework dependency を含めない
- runtime dependency は最小化し、schema validation library を採用する場合も DOM / network / storage dependency を持たないものに限定する
- source build は `tsconfig.json` により package source のみを対象とする
- test build は `tsconfig.test.json` により test artifact を source build と分離する
- npm package dry-run は test source と test artifact を package 内容に含めない
- generated artifact である `dist/`、`dist-test/`、`node_modules/` は repository tracking 対象外とする

**Initial repository files：**
- `package.json`
- `tsconfig.json`
- `mod.ts`
- `core/`
- `blocks/`
- `tools/`
- `commands/`
- `events/`
- `saver/`
- `publisher/`
- `sanitizer/`
- `transforms/`
- `types/`
- `tests/`

Repository root に UI app、demo app、storybook、CSS framework 設定を置かない。
必要な demo / playground は別 package または外部プロジェクトで扱う。

## 16. MVP Scope

初期実装は Headless Editor として成立する最小機能を優先する。
UI、保存先、公開先、外部形式変換は MVP に含めない。

**MVP必須：**
- EditorDocument / EditorBlock schema
- EditorController
- Tool registry
- block registry
- paragraph block
- heading block
- list block
- code block
- unsupported block
- bold inline tool
- italic inline tool
- link inline tool
- insert / delete / move / update / split / merge block command
- selection / caret state
- history / undo / redo
- read-only mode
- validation result
- sanitizer
- paste handling
- save request lifecycle
- publish request lifecycle
- event bus

**MVP対象外：**
- UI implementation
- DOM rendering
- external format parser
- external format serializer
- database persistence
- file-backed draft persistence
- network request
- Git operation
- auth / session
- collaboration

## 17. Acceptance Criteria

Adlaire-Editor の実装は以下を満たす必要がある。

- UI なしで EditorDocument を生成、更新、検証できる
- DOM なしで command dispatch、selection update、history update が動作する
- Public Editor API が storage、network、framework runtime に依存しない
- Tool は DOM を返さず、block / inline behavior のみを定義する
- Save は保存先へ書き込まず、SaveRequest を返す
- Publish は公開処理を実行せず、PublishRequest を返す
- Markdown / MDX / JSON parser / serializer を本体に含めない
- adapter interface を本体に含めない
- UI component、CSS、theme、icon を本体に含めない
- unsupported block の data を破棄しない
- validation error を構造化データとして返す
- 標準 command payload が本仕様の型と挙動に従う
- selection path が本仕様の path 規約に従う
- history は MVP で snapshot 方式として動作する
- read-only mode で document mutation command を拒否する
- normalize / sanitize / validate が定義された順序で実行される
- `dispatchBatch()` が batch 成功、batch 失敗 rollback、selection-only batch を仕様通り処理する
- malformed command、unknown command、malformed document が structured error として返る
- split / merge block command の edge case が仕様通り拒否または処理される
- default tool registry が default block registry と default inline tools を提供する
- npm build、npm test、npm package dry-run が通る
- repository operation rule は `AGENTS.md` に明記されている

## 17.1 Test Criteria

マスター仕様に対する実装検証は以下を必須とする。

- EditorDocument schema validation test
- block registry test
- tool registry test
- command dispatch test
- undo / redo test
- read-only guard test
- selection / caret state test
- sanitizer test
- validation error test
- save request lifecycle test
- publish request lifecycle test
- event emission test
- unsupported block retention test
- unsupported block edit guard test
- standard command payload behavior test
- selection path semantics test
- normalize / sanitize / validate order test
- dispatch batch rollback test
- selection-only command / batch dirty state test
- malformed command / unknown command error test
- malformed document validation test
- split / merge edge case test
- default inline tools test
- default tool registry test
- async validation test
- npm package dry-run content test
- no DOM / no storage / no network dependency test
- public API type test

Test は UI snapshot、DOM rendering、CSS、browser automation を必須にしない。

検証 command は最低限 `npm test` と `npm pack --dry-run` を含める。

## 18. Versioning

Adlaire-Editor は document schema version を持つ。
破壊的変更を行う場合は migration を提供する。

```ts
interface EditorDocumentMigration {
  from: string;
  to: string;
  migrate(document: EditorDocument): EditorDocument;
}
```

**Versioning policy：**
- `schemaVersion` は EditorDocument schema の互換性を表す
- patch version では既存 EditorDocument の意味を変更しない
- minor version では後方互換な block type、command、event を追加できる
- major version では migration を伴う破壊的変更のみ許可する
- migration は EditorDocument を入力し、EditorDocument を返す純粋変換とする

## 19. External Use Contract

Adlaire-Editor は外部プロジェクトを直接改変しない。
外部プロジェクトは Adlaire-Editor の headless editor API と EditorDocument を利用する。

外部プロジェクト側の責務：
- EditorDocument の生成
- EditorDocument から外部形式への変換
- 保存
- 公開
- preview
- asset handling
- session / auth
- UI 接続

Adlaire-Editor 本体仕様は本ファイルを正とする。
