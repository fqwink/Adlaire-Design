import { collectBlockIds, findBlock } from "../core/block-tree.js";
import { cloneJson } from "../core/clone.js";
import { editorError } from "../core/errors.js";
import { toRecord } from "../core/record.js";
import type { BlockRegistry } from "../blocks/registry.js";
import { normalizeBlock } from "../transforms/normalize.js";
import type {
  DeleteBlockPayload,
  EditorBlock,
  EditorDocument,
  EditorError,
  InsertBlockPayload,
  MergeBlockPayload,
  MoveBlockPayload,
  SetDocumentMetaPayload,
  SplitBlockPayload,
  UpdateBlockPayload,
} from "../types/public.js";

export type OperationResult = {
  document: EditorDocument;
  changed: boolean;
  errors: EditorError[];
};

export function insertBlock(document: EditorDocument, payload: InsertBlockPayload, registry: BlockRegistry): OperationResult {
  if (!isEditorBlockLike(payload.block)) {
    return unchanged(document, editorError("command.payload.invalid", "insert-block requires a block payload."));
  }
  const block = normalizeBlock(payload.block, registry);
  if (collectBlockIds(document.blocks).has(block.id)) {
    return unchanged(document, editorError("block.id.duplicate", "Inserted block id must be unique.", { blockId: block.id }));
  }
  if (payload.parentBlockId) {
    const parent = findBlock(document.blocks, payload.parentBlockId);
    if (!parent) {
      return unchanged(document, editorError("block.parent.notFound", "Parent block was not found.", { blockId: payload.parentBlockId }));
    }
    const parentTool = registry.get(parent.block.type);
    if (!parentTool?.allowsChildren) {
      return unchanged(document, editorError("block.children.notAllowed", `Block type '${parent.block.type}' does not allow nested blocks.`, { blockId: parent.block.id }));
    }
    return changed({
      ...document,
      blocks: updateBlockById(document.blocks, parent.block.id, (target) => ({
        ...target,
        children: insertAt(target.children ?? [], block, payload.index),
      })),
    });
  }
  return changed({
    ...document,
    blocks: insertAt(document.blocks, block, payload.index),
  });
}

export function deleteBlock(document: EditorDocument, payload: DeleteBlockPayload): OperationResult {
  if (typeof payload.blockId !== "string") {
    return unchanged(document, editorError("command.payload.invalid", "delete-block requires blockId."));
  }
  const location = findBlock(document.blocks, payload.blockId);
  if (!location) {
    return unchanged(document, editorError("block.notFound", "Block was not found.", { blockId: payload.blockId }));
  }
  return changed({
    ...document,
    blocks: removeBlockById(document.blocks, payload.blockId).blocks,
  });
}

export function moveBlock(document: EditorDocument, payload: MoveBlockPayload, registry: BlockRegistry): OperationResult {
  if (typeof payload.blockId !== "string" || typeof payload.toIndex !== "number") {
    return unchanged(document, editorError("command.payload.invalid", "move-block requires blockId and toIndex."));
  }
  const source = findBlock(document.blocks, payload.blockId);
  if (!source) {
    return unchanged(document, editorError("block.notFound", "Block was not found.", { blockId: payload.blockId }));
  }
  if (payload.fromParentBlockId !== undefined && source.parent?.id !== payload.fromParentBlockId) {
    return unchanged(document, editorError("block.parent.mismatch", "Source block parent does not match fromParentBlockId.", { blockId: payload.blockId }));
  }
  const removed = removeBlockById(document.blocks, payload.blockId);
  if (!removed.block) {
    return unchanged(document, editorError("block.notFound", "Block was not found.", { blockId: payload.blockId }));
  }
  if (payload.toParentBlockId) {
    const parent = findBlock(removed.blocks, payload.toParentBlockId);
    if (!parent) {
      return unchanged(document, editorError("block.parent.notFound", "Target parent block was not found.", { blockId: payload.toParentBlockId }));
    }
    const parentTool = registry.get(parent.block.type);
    if (!parentTool?.allowsChildren) {
      return unchanged(document, editorError("block.children.notAllowed", `Block type '${parent.block.type}' does not allow nested blocks.`, { blockId: parent.block.id }));
    }
    return changed({
      ...document,
      blocks: updateBlockById(removed.blocks, parent.block.id, (target) => ({
        ...target,
        children: insertAt(target.children ?? [], removed.block as EditorBlock, payload.toIndex),
      })),
    });
  }
  return changed({
    ...document,
    blocks: insertAt(removed.blocks, removed.block, payload.toIndex),
  });
}

export function updateBlock(document: EditorDocument, payload: UpdateBlockPayload, registry: BlockRegistry): OperationResult {
  if (typeof payload.blockId !== "string") {
    return unchanged(document, editorError("command.payload.invalid", "update-block requires blockId."));
  }
  const location = findBlock(document.blocks, payload.blockId);
  if (!location) {
    return unchanged(document, editorError("block.notFound", "Block was not found.", { blockId: payload.blockId }));
  }
  if (location.block.type === "unsupported" && payload.data !== undefined) {
    return unchanged(document, editorError("block.unsupported.readOnly", "Unsupported block data cannot be edited.", { blockId: payload.blockId }));
  }
  return changed({
    ...document,
    blocks: updateBlockById(document.blocks, payload.blockId, (block) => normalizeBlock({
      ...block,
      data: payload.data === undefined ? block.data : payload.data,
      ...(payload.meta === undefined ? {} : { meta: { ...block.meta, ...payload.meta } }),
    }, registry)),
  });
}

export function splitBlock(document: EditorDocument, payload: SplitBlockPayload, registry: BlockRegistry): OperationResult {
  if (typeof payload.blockId !== "string" || !isRecord(payload.position)) {
    return unchanged(document, editorError("command.payload.invalid", "split-block requires blockId and position."));
  }
  const location = findBlock(document.blocks, payload.blockId);
  if (!location) {
    return unchanged(document, editorError("block.notFound", "Block was not found.", { blockId: payload.blockId }));
  }
  if (location.block.type === "unsupported") {
    return unchanged(document, editorError("block.unsupported.split", "Unsupported block cannot be split.", { blockId: payload.blockId }));
  }
  if (collectBlockIds(document.blocks).has(`${location.block.id}-split`)) {
    return unchanged(document, editorError("block.id.duplicate", "Split target block id already exists.", { blockId: `${location.block.id}-split` }));
  }
  const split = splitBlockData(location.block, payload);
  if (!split) {
    return unchanged(document, editorError(
      "block.split.unsupported",
      "Block cannot be split at the requested position.",
      {
        blockId: payload.blockId,
        ...(payload.position.path === undefined ? {} : { path: payload.position.path }),
      },
    ));
  }
  const [left, right] = split;
  const siblings = location.siblings;
  const nextSiblings = [
    ...siblings.slice(0, location.index),
    normalizeBlock(left, registry),
    normalizeBlock(right, registry),
    ...siblings.slice(location.index + 1),
  ];
  if (!location.parent) {
    return changed({ ...document, blocks: nextSiblings });
  }
  return changed({
    ...document,
    blocks: updateBlockById(document.blocks, location.parent.id, (parent) => ({ ...parent, children: nextSiblings })),
  });
}

export function mergeBlock(document: EditorDocument, payload: MergeBlockPayload, registry: BlockRegistry): OperationResult {
  if (typeof payload.sourceBlockId !== "string" || typeof payload.targetBlockId !== "string") {
    return unchanged(document, editorError("command.payload.invalid", "merge-block requires sourceBlockId and targetBlockId."));
  }
  if (payload.sourceBlockId === payload.targetBlockId) {
    return unchanged(document, editorError("block.merge.sameBlock", "A block cannot be merged into itself.", { blockId: payload.sourceBlockId }));
  }
  const source = findBlock(document.blocks, payload.sourceBlockId);
  const target = findBlock(document.blocks, payload.targetBlockId);
  if (!source || !target) {
    return unchanged(document, editorError("block.notFound", "Source or target block was not found."));
  }
  if (source.block.type === "unsupported" || target.block.type === "unsupported") {
    return unchanged(document, editorError("block.unsupported.merge", "Unsupported block cannot be merged."));
  }
  if (source.block.type !== target.block.type) {
    return unchanged(document, editorError("block.merge.typeMismatch", "Only blocks of the same type can be merged."));
  }
  const tool = registry.get(target.block.type);
  if (!tool?.merge) {
    return unchanged(document, editorError("block.merge.unsupported", `Block type '${target.block.type}' does not support merge.`, { blockId: target.block.id }));
  }
  const mergedData = tool.merge(target.block.data, source.block.data);
  const withoutSource = removeBlockById(document.blocks, source.block.id).blocks;
  return changed({
    ...document,
    blocks: updateBlockById(withoutSource, target.block.id, (block) => normalizeBlock({ ...block, data: toRecord(mergedData) }, registry)),
  });
}

export function setDocumentMeta(document: EditorDocument, payload: SetDocumentMetaPayload): OperationResult {
  if (!isRecord(payload.meta)) {
    return unchanged(document, editorError("command.payload.invalid", "set-document-meta requires meta."));
  }
  return changed({
    ...document,
    meta: payload.merge ? { ...document.meta, ...payload.meta } : cloneJson(payload.meta),
  });
}

function splitBlockData(block: EditorBlock, payload: SplitBlockPayload): [EditorBlock, EditorBlock] | null {
  if (block.type === "code" && payload.position.path?.[0] === "code") {
    const code = typeof block.data.code === "string" ? block.data.code : "";
    const offset = payload.position.offset ?? code.length;
    if (!Number.isInteger(offset) || offset < 0 || offset > code.length) {
      return null;
    }
    return [
      { ...block, data: { ...block.data, code: code.slice(0, offset) } },
      { ...block, id: `${block.id}-split`, data: { ...block.data, code: code.slice(offset) } },
    ];
  }
  if ((block.type === "paragraph" || block.type === "heading") && payload.position.path?.[0] === "text") {
    const index = payload.position.path[1];
    if (typeof index !== "number" || !Array.isArray(block.data.text)) {
      return null;
    }
    const inline = block.data.text[index];
    if (!isTextInline(inline)) {
      return null;
    }
    const offset = payload.position.offset ?? inline.text.length;
    if (!Number.isInteger(offset) || offset < 0 || offset > inline.text.length) {
      return null;
    }
    const beforeInline = { ...inline, text: inline.text.slice(0, offset) };
    const afterInline = { ...inline, text: inline.text.slice(offset) };
    return [
      { ...block, data: { ...block.data, text: [...block.data.text.slice(0, index), beforeInline] } },
      { ...block, id: `${block.id}-split`, data: { ...block.data, text: [afterInline, ...block.data.text.slice(index + 1)] } },
    ];
  }
  return null;
}

function updateBlockById(blocks: EditorBlock[], blockId: string, updater: (block: EditorBlock) => EditorBlock): EditorBlock[] {
  return blocks.map((block) => {
    if (block.id === blockId) {
      return updater(block);
    }
    if (block.children) {
      return { ...block, children: updateBlockById(block.children, blockId, updater) };
    }
    return block;
  });
}

function removeBlockById(blocks: EditorBlock[], blockId: string): { blocks: EditorBlock[]; block: EditorBlock | null } {
  let removed: EditorBlock | null = null;
  const next: EditorBlock[] = [];
  for (const block of blocks) {
    if (block.id === blockId) {
      removed = block;
      continue;
    }
    if (block.children) {
      const childResult = removeBlockById(block.children, blockId);
      if (childResult.block) {
        removed = childResult.block;
        next.push({ ...block, children: childResult.blocks });
        continue;
      }
    }
    next.push(block);
  }
  return { blocks: next, block: removed };
}

function insertAt(blocks: EditorBlock[], block: EditorBlock, index?: number): EditorBlock[] {
  const next = [...blocks];
  const normalizedIndex = index === undefined ? next.length : Math.max(0, Math.min(index, next.length));
  next.splice(normalizedIndex, 0, block);
  return next;
}

function unchanged(document: EditorDocument, error: EditorError): OperationResult {
  return { document, changed: false, errors: [error] };
}

function changed(document: EditorDocument): OperationResult {
  return { document, changed: true, errors: [] };
}

function isTextInline(value: unknown): value is { type: "text"; text: string; marks?: unknown[] } {
  return typeof value === "object"
    && value !== null
    && !Array.isArray(value)
    && (value as { type?: unknown }).type === "text"
    && typeof (value as { text?: unknown }).text === "string";
}

function isEditorBlockLike(value: unknown): value is EditorBlock {
  return isRecord(value)
    && typeof value.id === "string"
    && typeof value.type === "string"
    && isRecord(value.data);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
