import type { BlockTool } from "../tools/block-tool.js";
import type { UnsupportedData } from "../types/public.js";
export declare const unsupportedTool: BlockTool<UnsupportedData>;
//# sourceMappingURL=unsupported.d.ts.map