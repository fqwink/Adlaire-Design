export const codeTool = {
    type: "code",
    kind: "block",
    create: () => ({ code: "" }),
    normalize: (data) => ({
        code: typeof data.code === "string" ? data.code : "",
        ...(typeof data.language === "string" && data.language.length > 0 ? { language: data.language } : {}),
    }),
    validate: (data) => {
        return typeof data.code === "string" && (data.language === undefined || typeof data.language === "string");
    },
    sanitize: {},
    merge: (left, right) => ({
        code: `${typeof left.code === "string" ? left.code : ""}\n${typeof right.code === "string" ? right.code : ""}`,
        ...(typeof left.language === "string" ? { language: left.language } : {}),
    }),
};
//# sourceMappingURL=code.js.map