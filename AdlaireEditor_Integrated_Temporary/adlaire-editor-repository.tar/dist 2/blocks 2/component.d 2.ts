import type { BlockTool } from "../tools/block-tool.js";
export declare const componentTool: BlockTool;
//# sourceMappingURL=component.d.ts.map