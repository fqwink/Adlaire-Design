import { cloneJson } from "./clone.js";
export class History {
    #undoStack = [];
    #redoStack = [];
    #limit;
    constructor(limit = 100) {
        this.#limit = Math.max(0, limit);
    }
    get canUndo() {
        return this.#undoStack.length > 0;
    }
    get canRedo() {
        return this.#redoStack.length > 0;
    }
    push(entry) {
        if (this.#limit === 0) {
            return;
        }
        this.#undoStack.push(cloneJson(entry));
        while (this.#undoStack.length > this.#limit) {
            this.#undoStack.shift();
        }
        this.#redoStack.length = 0;
    }
    undo(currentDocument, currentSelection) {
        const entry = this.#undoStack.pop();
        if (!entry) {
            return null;
        }
        this.#redoStack.push({
            before: {
                document: cloneJson(entry.before.document),
                selection: cloneJson(entry.before.selection),
            },
            after: {
                document: cloneJson(currentDocument),
                selection: cloneJson(currentSelection),
            },
            commands: cloneJson(entry.commands),
        });
        return cloneJson(entry);
    }
    redo() {
        const entry = this.#redoStack.pop();
        if (!entry) {
            return null;
        }
        this.#undoStack.push(cloneJson(entry));
        return cloneJson(entry);
    }
}
//# sourceMappingURL=history.js.map