import { ToolRegistry } from "../tools/tool.js";
import type { EditorTool } from "../types/public.js";
export declare class BlockRegistry extends ToolRegistry {
    register(tool: EditorTool): void;
}
export declare function createDefaultBlockRegistry(extraTools?: EditorTool[]): BlockRegistry;
//# sourceMappingURL=registry.d.ts.map