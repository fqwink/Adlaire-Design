import type { BlockTool } from "../tools/block-tool.js";
import type { CodeData } from "../types/public.js";
export declare const codeTool: BlockTool<CodeData>;
//# sourceMappingURL=code.d.ts.map