export const boldTool = {
    type: "bold",
    kind: "inline",
    normalize: (data) => ({ ...data }),
    validate: () => true,
    sanitize: {},
};
export const italicTool = {
    type: "italic",
    kind: "inline",
    normalize: (data) => ({ ...data }),
    validate: () => true,
    sanitize: {},
};
export const linkTool = {
    type: "link",
    kind: "inline",
    normalize: (data) => ({ ...data }),
    validate: (data) => typeof data.href === "string",
    sanitize: {},
};
export const codeInlineTool = {
    type: "code",
    kind: "inline",
    normalize: (data) => ({ ...data }),
    validate: () => true,
    sanitize: {},
};
export const strikeTool = {
    type: "strike",
    kind: "inline",
    normalize: (data) => ({ ...data }),
    validate: () => true,
    sanitize: {},
};
export function createDefaultInlineTools() {
    return [boldTool, italicTool, linkTool, codeInlineTool, strikeTool];
}
//# sourceMappingURL=inline.js.map