export { updateBlock } from "./operations.js";
//# sourceMappingURL=update-block.d.ts.map