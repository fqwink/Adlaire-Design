import { validateDocument } from "../core/validation.js";
import { sanitizeDocument } from "../sanitizer/sanitize.js";
import { normalizeDocument } from "../transforms/normalize.js";
export function createPublishRequest(document, registry, context = { reason: "manual" }) {
    const normalized = normalizeDocument(document, registry);
    const sanitized = sanitizeDocument(normalized, registry);
    return {
        document: sanitized,
        context,
        validation: validateDocument(sanitized, registry),
    };
}
//# sourceMappingURL=publish.js.map