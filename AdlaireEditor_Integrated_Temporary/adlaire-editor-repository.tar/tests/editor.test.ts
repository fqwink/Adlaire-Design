import assert from "node:assert/strict";
import test from "node:test";
import {
  createEditor,
  createDefaultBlockRegistry,
  createDefaultInlineTools,
  createDefaultToolRegistry,
  handlePaste,
  getFirstBlockPosition,
  getLastBlockPosition,
  getNextBlockPosition,
  getPreviousBlockPosition,
  normalizeDocument,
  sanitizeDocument,
  validateDocument,
  validateDocumentAsync,
  type EditorDocument,
  type EditorTool,
} from "../mod.js";

function doc(): EditorDocument {
  return {
    id: "doc-1",
    schemaVersion: "1.0.0",
    blocks: [
      {
        id: "p1",
        type: "paragraph",
        data: {
          text: [{ type: "text", text: "hello" }],
        },
      },
    ],
  };
}

test("EditorDocument schema validation detects required structure", () => {
  const registry = createDefaultBlockRegistry();
  const result = validateDocument(doc(), registry);
  assert.equal(result.valid, true);
  assert.deepEqual(result.errors, []);
});

test("block registry keeps unregistered blocks as unsupported without data loss", () => {
  const registry = createDefaultBlockRegistry();
  const normalized = normalizeDocument({
    id: "doc-1",
    schemaVersion: "1.0.0",
    blocks: [
      {
        id: "x1",
        type: "legacy",
        data: { payload: 1 },
      },
    ],
  }, registry);

  assert.equal(normalized.blocks[0]?.type, "unsupported");
  assert.deepEqual(normalized.blocks[0]?.data, {
    originalType: "legacy",
    originalData: { payload: 1 },
  });
  const validation = validateDocument(normalized, registry);
  assert.equal(validation.valid, true);
  assert.equal(validation.warnings[0]?.code, "block.unsupported");
});

test("command dispatch inserts, updates, deletes, moves, splits and merges blocks", () => {
  const editor = createEditor({ document: doc() });

  assert.equal(editor.dispatch({
    type: "insert-block",
    payload: { block: { id: "p2", type: "paragraph", data: { text: [{ type: "text", text: " world" }] } } },
  }).changed, true);
  assert.equal(editor.getDocument().blocks.length, 2);

  assert.equal(editor.dispatch({
    type: "update-block",
    payload: { blockId: "p2", data: { text: [{ type: "text", text: "world" }] } },
  }).changed, true);
  assert.equal((editor.getDocument().blocks[1]?.data.text as Array<{ text: string }>)[0]?.text, "world");

  assert.equal(editor.dispatch({
    type: "move-block",
    payload: { blockId: "p2", toIndex: 0 },
  }).changed, true);
  assert.equal(editor.getDocument().blocks[0]?.id, "p2");

  assert.equal(editor.dispatch({
    type: "split-block",
    payload: { blockId: "p2", position: { blockId: "p2", path: ["text", 0, "text"], offset: 3 } },
  }).changed, true);
  assert.equal(editor.getDocument().blocks[0]?.id, "p2");
  assert.equal(editor.getDocument().blocks[1]?.id, "p2-split");

  assert.equal(editor.dispatch({
    type: "merge-block",
    payload: { targetBlockId: "p2", sourceBlockId: "p2-split" },
  }).changed, true);
  assert.equal((editor.getDocument().blocks[0]?.data.text as Array<{ text: string }>)[0]?.text, "world");

  assert.equal(editor.dispatch({
    type: "delete-block",
    payload: { blockId: "p2" },
  }).changed, true);
  assert.equal(editor.getDocument().blocks.some((block) => block.id === "p2"), false);
});

test("undo and redo restore snapshot history", () => {
  const editor = createEditor({ document: doc() });
  editor.dispatch({
    type: "insert-block",
    payload: { block: { id: "p2", type: "paragraph", data: { text: [] } } },
  });
  assert.equal(editor.getDocument().blocks.length, 2);
  assert.equal(editor.undo().changed, true);
  assert.equal(editor.getDocument().blocks.length, 1);
  assert.equal(editor.redo().changed, true);
  assert.equal(editor.getDocument().blocks.length, 2);
});

test("read-only guard rejects document mutation and allows selection/save/publish", () => {
  const editor = createEditor({ document: doc(), readOnly: true });
  const rejected = editor.dispatch({
    type: "insert-block",
    payload: { block: { id: "p2", type: "paragraph", data: { text: [] } } },
  });
  assert.equal(rejected.changed, false);
  assert.equal(rejected.errors?.[0]?.code, "command.readOnly");

  editor.setSelection({
    mode: "caret",
    anchor: { blockId: "p1", path: ["text", 0, "text"], offset: 1 },
    focus: { blockId: "p1", path: ["text", 0, "text"], offset: 1 },
  });
  assert.equal(editor.getSelection()?.mode, "caret");
  assert.equal(editor.save().context.reason, "manual");
  assert.equal(editor.requestPublish().context.reason, "manual");
});

test("selection path semantics reject unknown paths", () => {
  const editor = createEditor({ document: doc() });
  const result = editor.dispatch({
    type: "set-selection",
    payload: {
      selection: {
        mode: "caret",
        anchor: { blockId: "p1", path: ["unknown"], offset: 0 },
        focus: { blockId: "p1", path: ["unknown"], offset: 0 },
      },
    },
  });
  assert.equal(result.changed, false);
  assert.equal(result.errors?.[0]?.code, "selection.invalid");
});

test("sanitizer strips unsafe link marks before validation lifecycle output", () => {
  const registry = createDefaultBlockRegistry();
  const unsafe: EditorDocument = {
    id: "doc-1",
    schemaVersion: "1.0.0",
    blocks: [
      {
        id: "p1",
        type: "paragraph",
        data: {
          text: [{ type: "text", text: "x", marks: [{ type: "link", href: "javascript:alert(1)" }] }],
        },
      },
    ],
  };
  const sanitized = sanitizeDocument(normalizeDocument(unsafe, registry), registry);
  const text = sanitized.blocks[0]?.data.text as Array<{ marks?: unknown[] }>;
  assert.equal(text[0]?.marks, undefined);
  assert.equal(validateDocument(sanitized, registry).valid, true);
});

test("save and publish emit request lifecycle without storage or network", () => {
  const events: string[] = [];
  const editor = createEditor({ document: doc() });
  editor.subscribe((event) => events.push(event.type));

  const saveResult = editor.dispatch({ type: "save", payload: {} });
  const publishResult = editor.dispatch({ type: "request-publish", payload: {} });

  assert.equal(saveResult.changed, false);
  assert.equal(publishResult.changed, false);
  assert.deepEqual(events, ["save:requested", "publish:requested"]);
});

test("direct save and publish calls emit lifecycle events", () => {
  const events: string[] = [];
  const editor = createEditor({ document: doc() });
  editor.subscribe((event) => events.push(event.type));
  editor.save();
  editor.requestPublish();
  assert.deepEqual(events, ["save:requested", "publish:requested"]);
});

test("unsupported block data cannot be edited but can be deleted", () => {
  const editor = createEditor({
    document: {
      id: "doc-1",
      schemaVersion: "1.0.0",
      blocks: [{ id: "u1", type: "missing", data: { raw: true } }],
    },
  });

  const update = editor.dispatch({
    type: "update-block",
    payload: { blockId: "u1", data: { originalType: "missing", originalData: {} } },
  });
  assert.equal(update.changed, false);
  assert.equal(update.errors?.[0]?.code, "block.unsupported.readOnly");

  const deletion = editor.dispatch({ type: "delete-block", payload: { blockId: "u1" } });
  assert.equal(deletion.changed, true);
});

test("paste handling delegates to headless tool hooks", async () => {
  const pasteTool: EditorTool = {
    type: "paste-block",
    kind: "block",
    onPaste: (event) => ({ text: [{ type: "text", text: String(event.data) }] }),
  };
  const registry = createDefaultBlockRegistry([pasteTool]);
  const blocks = await handlePaste({ type: "text", data: "hello" }, registry);
  assert.equal(blocks[0]?.type, "paste-block");
});

test("batch dispatch creates a single undoable history entry", () => {
  const editor = createEditor({ document: doc() });
  const result = editor.dispatchBatch([
    { type: "insert-block", payload: { block: { id: "p2", type: "paragraph", data: { text: [] } } } },
    { type: "insert-block", payload: { block: { id: "p3", type: "paragraph", data: { text: [] } } } },
  ]);
  assert.equal(result.changed, true);
  assert.equal(editor.getDocument().blocks.length, 3);
  editor.undo();
  assert.equal(editor.getDocument().blocks.length, 1);
});

test("default inline tools include MVP inline marks", () => {
  assert.deepEqual(createDefaultInlineTools().map((tool) => tool.type), [
    "bold",
    "italic",
    "link",
    "code",
    "strike",
  ]);
});

test("malformed command payload returns structured error without throwing", () => {
  const editor = createEditor({ document: doc() });
  const result = editor.dispatch({ type: "insert-block", payload: {} });
  assert.equal(result.changed, false);
  assert.equal(result.errors?.[0]?.code, "command.payload.invalid");
});

test("invalid and unknown commands return structured errors without throwing", () => {
  const editor = createEditor({ document: doc() });
  const invalid = editor.dispatch(null as never);
  assert.equal(invalid.changed, false);
  assert.equal(invalid.errors?.[0]?.code, "command.invalid");
  const unknown = editor.dispatch({ type: "unknown", payload: {} });
  assert.equal(unknown.changed, false);
  assert.equal(unknown.errors?.[0]?.code, "command.unknown");
  assert.equal(editor.canDispatch({ type: "unknown", payload: {} }), false);
});

test("batch rejects invalid command entries without partial commit", () => {
  const editor = createEditor({ document: doc() });
  const result = editor.dispatchBatch([
    { type: "insert-block", payload: { block: { id: "p2", type: "paragraph", data: { text: [] } } } },
    null as never,
  ]);
  assert.equal(result.changed, false);
  assert.equal(result.errors?.[0]?.code, "command.invalid");
  assert.equal(editor.getDocument().blocks.length, 1);
});

test("merge rejects same source and target block", () => {
  const editor = createEditor({ document: doc() });
  const result = editor.dispatch({
    type: "merge-block",
    payload: { sourceBlockId: "p1", targetBlockId: "p1" },
  });
  assert.equal(result.changed, false);
  assert.equal(result.errors?.[0]?.code, "block.merge.sameBlock");
  assert.equal(editor.getDocument().blocks.length, 1);
});

test("split rejects invalid offsets and duplicate generated ids", () => {
  const editor = createEditor({
    document: {
      ...doc(),
      blocks: [
        ...doc().blocks,
        { id: "p1-split", type: "paragraph", data: { text: [] } },
      ],
    },
  });
  const duplicate = editor.dispatch({
    type: "split-block",
    payload: { blockId: "p1", position: { blockId: "p1", path: ["text", 0, "text"], offset: 2 } },
  });
  assert.equal(duplicate.changed, false);
  assert.equal(duplicate.errors?.[0]?.code, "block.id.duplicate");

  const offsetEditor = createEditor({ document: doc() });
  const invalidOffset = offsetEditor.dispatch({
    type: "split-block",
    payload: { blockId: "p1", position: { blockId: "p1", path: ["text", 0, "text"], offset: 99 } },
  });
  assert.equal(invalidOffset.changed, false);
  assert.equal(invalidOffset.errors?.[0]?.code, "block.split.unsupported");
});

test("validation handles malformed document shape without throwing", () => {
  const registry = createDefaultBlockRegistry();
  const result = validateDocument({
    id: "bad",
    schemaVersion: "1.0.0",
    blocks: "not-array",
  } as never, registry);
  assert.equal(result.valid, false);
  assert.equal(result.errors[0]?.code, "document.blocks.invalid");

  const nullResult = validateDocument(null as never, registry);
  assert.equal(nullResult.valid, false);
  assert.equal(nullResult.errors[0]?.code, "document.invalid");
});

test("selection-only commands do not mark save state dirty or emit document changed", () => {
  const events: string[] = [];
  const editor = createEditor({ document: doc() });
  editor.subscribe((event) => events.push(event.type));
  const selection = {
    mode: "caret" as const,
    anchor: { blockId: "p1", path: ["text", 0, "text"], offset: 1 },
    focus: { blockId: "p1", path: ["text", 0, "text"], offset: 1 },
  };
  editor.dispatch({ type: "set-selection", payload: { selection } });
  assert.equal(editor.save().state.dirty, false);
  assert.deepEqual(events.filter((event) => event === "document:changed"), []);

  events.length = 0;
  editor.undo();
  assert.deepEqual(events.filter((event) => event === "document:changed"), []);
});

test("setting identical selection is a no-op", () => {
  const editor = createEditor({ document: doc() });
  const selection = {
    mode: "caret" as const,
    anchor: { blockId: "p1", path: ["text", 0, "text"], offset: 1 },
    focus: { blockId: "p1", path: ["text", 0, "text"], offset: 1 },
  };
  assert.equal(editor.dispatch({ type: "set-selection", payload: { selection } }).changed, true);
  assert.equal(editor.dispatch({ type: "set-selection", payload: { selection } }).changed, false);
  assert.equal(editor.dispatchBatch([{ type: "set-selection", payload: { selection } }]).changed, false);
});

test("selection-only batch does not emit document changed", () => {
  const events: string[] = [];
  const editor = createEditor({ document: doc() });
  editor.subscribe((event) => events.push(event.type));
  const selection = {
    mode: "caret" as const,
    anchor: { blockId: "p1", path: ["text", 0, "text"], offset: 2 },
    focus: { blockId: "p1", path: ["text", 0, "text"], offset: 2 },
  };
  editor.dispatchBatch([{ type: "set-selection", payload: { selection } }]);
  assert.equal(editor.save().state.dirty, false);
  assert.deepEqual(events.filter((event) => event === "document:changed"), []);
});

test("default tool registry includes block and inline tools", () => {
  const registry = createDefaultToolRegistry();
  assert.equal(registry.has("paragraph"), true);
  assert.equal(registry.has("bold"), true);
  assert.equal(registry.has("link"), true);
});

test("move validates fromParentBlockId when provided", () => {
  const containerTool: EditorTool = {
    type: "container",
    kind: "block",
    allowsChildren: true,
    normalize: (data) => data,
    validate: () => true,
  };
  const editor = createEditor({
    tools: [containerTool],
    document: {
      id: "doc-1",
      schemaVersion: "1.0.0",
      blocks: [
        {
          id: "c1",
          type: "container",
          data: {},
          children: [{ id: "p1", type: "paragraph", data: { text: [] } }],
        },
      ],
    },
  });
  const result = editor.dispatch({
    type: "move-block",
    payload: { blockId: "p1", fromParentBlockId: "wrong", toIndex: 0 },
  });
  assert.equal(result.changed, false);
  assert.equal(result.errors?.[0]?.code, "block.parent.mismatch");
});

test("save lifecycle validates request document and emits validation errors", () => {
  const events: string[] = [];
  const invalidTool: EditorTool = {
    type: "invalid-block",
    kind: "block",
    normalize: (data) => data,
    validate: () => false,
  };
  const editor = createEditor({
    tools: [invalidTool],
    document: {
      id: "doc-1",
      schemaVersion: "1.0.0",
      blocks: [{ id: "bad", type: "invalid-block", data: {} }],
    },
  });
  editor.subscribe((event) => events.push(event.type === "error" ? `error:${event.error.code}` : event.type));
  editor.save();
  assert.equal(events.includes("error:block.data.invalid"), true);
  assert.equal(events.includes("save:requested"), true);
});

test("caret helpers move across flattened block order", () => {
  const document: EditorDocument = {
    ...doc(),
    blocks: [
      ...doc().blocks,
      { id: "p2", type: "paragraph", data: { text: [] } },
      { id: "p3", type: "paragraph", data: { text: [] } },
    ],
  };
  assert.deepEqual(getFirstBlockPosition(document), { blockId: "p1" });
  assert.deepEqual(getLastBlockPosition(document), { blockId: "p3" });
  assert.deepEqual(getNextBlockPosition(document, "p1"), { blockId: "p2" });
  assert.deepEqual(getPreviousBlockPosition(document, "p3"), { blockId: "p2" });
});

test("async validation helper supports asynchronous tool validation", async () => {
  const asyncTool: EditorTool = {
    type: "async-block",
    kind: "block",
    validate: (data) => Promise.resolve(typeof (data as { ok?: unknown }).ok === "boolean"),
  };
  const registry = createDefaultBlockRegistry([asyncTool]);
  const document: EditorDocument = {
    id: "doc-1",
    schemaVersion: "1.0.0",
    blocks: [{ id: "a1", type: "async-block", data: { ok: true } }],
  };

  assert.equal(validateDocument(document, registry).valid, false);
  assert.equal((await validateDocumentAsync(document, registry)).valid, true);
});
