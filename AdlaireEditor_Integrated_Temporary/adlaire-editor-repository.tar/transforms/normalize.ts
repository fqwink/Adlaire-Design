import type { BlockRegistry } from "../blocks/registry.js";
import { cloneJson } from "../core/clone.js";
import { toRecord } from "../core/record.js";
import type { EditorBlock, EditorDocument, UnsupportedData } from "../types/public.js";

export function normalizeDocument(document: EditorDocument, registry: BlockRegistry): EditorDocument {
  return {
    id: typeof document.id === "string" && document.id.length > 0 ? document.id : "document",
    schemaVersion: typeof document.schemaVersion === "string" && document.schemaVersion.length > 0 ? document.schemaVersion : "1.0.0",
    blocks: Array.isArray(document.blocks) ? document.blocks.map((block) => normalizeBlock(block, registry)) : [],
    ...(document.meta === undefined ? {} : { meta: cloneJson(document.meta) }),
  };
}

export function normalizeBlock(block: EditorBlock, registry: BlockRegistry): EditorBlock {
  const rawType = typeof block.type === "string" && block.type.length > 0 ? block.type : "unsupported";
  const type = registry.has(rawType) ? rawType : "unsupported";
  const rawData = toRecord(cloneJson(block.data ?? {}));
  const tool = registry.get(type);
  const data = toRecord(type === "unsupported" && rawType !== "unsupported"
    ? ({ originalType: rawType, originalData: rawData } satisfies UnsupportedData)
    : tool?.normalize?.(rawData) ?? rawData);
  const normalized: EditorBlock = {
    id: typeof block.id === "string" && block.id.length > 0 ? block.id : createStableFallbackId(rawType, rawData),
    type,
    data,
    ...(block.meta === undefined ? {} : { meta: cloneJson(block.meta) }),
  };
  if (block.children && block.children.length > 0) {
    normalized.children = block.children.map((child) => normalizeBlock(child, registry));
  }
  return normalized;
}

function createStableFallbackId(type: string, data: Record<string, unknown>): string {
  const encoded = JSON.stringify({ type, data });
  let hash = 0;
  for (let index = 0; index < encoded.length; index += 1) {
    hash = ((hash << 5) - hash + encoded.charCodeAt(index)) | 0;
  }
  return `block-${Math.abs(hash)}`;
}
