import type { EditorEvent, EditorEventListener, Unsubscribe } from "../types/public.js";

export class EventBus {
  readonly #listeners = new Set<EditorEventListener>();

  subscribe(listener: EditorEventListener): Unsubscribe {
    this.#listeners.add(listener);
    return () => {
      this.#listeners.delete(listener);
    };
  }

  emit(event: EditorEvent): void {
    for (const listener of [...this.#listeners]) {
      listener(event);
    }
  }

  clear(): void {
    this.#listeners.clear();
  }
}
