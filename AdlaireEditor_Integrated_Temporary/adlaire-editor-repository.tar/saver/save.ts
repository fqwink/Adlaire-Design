import type { BlockRegistry } from "../blocks/registry.js";
import { sanitizeDocument } from "../sanitizer/sanitize.js";
import { normalizeDocument } from "../transforms/normalize.js";
import type { EditorDocument, SaveContext, SaveRequest, SaveState } from "../types/public.js";

export function createSaveRequest(
  document: EditorDocument,
  registry: BlockRegistry,
  state: SaveState,
  context: SaveContext = { reason: "manual" },
): SaveRequest {
  const normalized = normalizeDocument(document, registry);
  const sanitized = sanitizeDocument(normalized, registry);
  return {
    document: sanitized,
    context,
    state: {
      ...state,
      saving: true,
      lastRequestedAt: new Date().toISOString(),
    },
  };
}
