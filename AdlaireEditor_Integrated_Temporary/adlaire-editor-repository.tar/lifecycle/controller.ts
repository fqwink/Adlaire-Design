import { createDefaultBlockRegistry, type BlockRegistry } from "../blocks/registry.js";
import { deleteBlock, insertBlock, mergeBlock, moveBlock, setDocumentMeta, splitBlock, updateBlock } from "../commands/operations.js";
import { History } from "../core/history.js";
import { normalizeConfig } from "../core/config.js";
import { createEmptyDocument } from "../core/document.js";
import { editorError } from "../core/errors.js";
import { normalizeSelection } from "../core/selection.js";
import { validateDocument } from "../core/validation.js";
import { EventBus } from "../events/event-bus.js";
import { createPublishRequest } from "../publisher/publish.js";
import { createSaveRequest } from "../saver/save.js";
import { normalizeDocument } from "../transforms/normalize.js";
import type {
  DeleteBlockPayload,
  EditorCommand,
  EditorCommandResult,
  EditorConfig,
  EditorController,
  EditorDocument,
  EditorError,
  EditorSelection,
  InsertBlockPayload,
  MergeBlockPayload,
  MoveBlockPayload,
  PublishContext,
  PublishRequest,
  SaveContext,
  SaveRequest,
  SaveState,
  SetDocumentMetaPayload,
  SetSelectionPayload,
  SplitBlockPayload,
  Unsubscribe,
  UpdateBlockPayload,
  EditorEventListener,
} from "../types/public.js";

type MutableCommandType =
  | "insert-block"
  | "delete-block"
  | "move-block"
  | "update-block"
  | "split-block"
  | "merge-block"
  | "set-document-meta";

const mutableCommandTypes = new Set<string>([
  "insert-block",
  "delete-block",
  "move-block",
  "update-block",
  "split-block",
  "merge-block",
  "set-document-meta",
]);

export class HeadlessEditorController implements EditorController {
  readonly #registry: BlockRegistry;
  readonly #events = new EventBus();
  readonly #history: History;
  readonly #readOnly: boolean;
  #document: EditorDocument;
  #selection: EditorSelection | null = null;
  #dirty = false;
  #saveState: SaveState = { dirty: false, saving: false };

  constructor(config: EditorConfig = {}) {
    const normalizedConfig = normalizeConfig(config);
    this.#registry = createDefaultBlockRegistry(normalizedConfig.tools ?? []);
    if (!this.#registry.has(normalizedConfig.defaultBlock)) {
      throw new Error(`Default block '${normalizedConfig.defaultBlock}' is not registered.`);
    }
    this.#history = new History(normalizedConfig.historyLimit);
    this.#readOnly = normalizedConfig.readOnly;
    this.#document = normalizeDocument(normalizedConfig.document ?? createEmptyDocument(), this.#registry);
    const validation = validateDocument(this.#document, this.#registry);
    for (const error of validation.errors) {
      this.#events.emit({ type: "error", error });
    }
  }

  getDocument(): EditorDocument {
    return structuredCloneJson(this.#document);
  }

  setDocument(document: EditorDocument): void {
    const normalized = normalizeDocument(document, this.#registry);
    const validation = validateDocument(normalized, this.#registry);
    this.#document = normalized;
    this.#selection = normalizeSelection(this.#document, this.#selection);
    this.#dirty = false;
    this.#saveState = { dirty: false, saving: false };
    this.#events.emit({ type: "document:changed", document: this.getDocument() });
    this.#events.emit({ type: "selection:changed", selection: this.getSelection() });
    for (const error of validation.errors) {
      this.#emitError(error);
    }
  }

  dispatch(command: EditorCommand): EditorCommandResult {
    if (!isEditorCommand(command)) {
      return this.#errorResult(editorError("command.invalid", "Command must be an object with a string type."));
    }
    if (!isKnownCommandType(command.type)) {
      return this.#errorResult(editorError("command.unknown", `Command '${command.type}' is not registered.`));
    }
    if (!this.canDispatch(command)) {
      return this.#errorResult(editorError("command.readOnly", `Command '${command.type}' is not allowed in read-only mode.`));
    }

    if (command.type === "set-selection") {
      if (!isRecord(command.payload)) {
        return this.#errorResult(editorError("command.payload.invalid", "set-selection payload must be an object."));
      }
      return this.#dispatchSelection(command as EditorCommand<SetSelectionPayload>);
    }
    if (command.type === "save") {
      const payload = isRecord(command.payload) ? command.payload as { context?: SaveContext } : {};
      this.save(payload.context);
      return { document: this.getDocument(), selection: this.getSelection(), changed: false };
    }
    if (command.type === "request-publish") {
      const payload = isRecord(command.payload) ? command.payload as { context?: PublishContext } : {};
      this.requestPublish(payload.context);
      return { document: this.getDocument(), selection: this.getSelection(), changed: false };
    }

    const before = {
      document: this.getDocument(),
      selection: this.getSelection(),
    };
    const operation = this.#applyMutableCommand(this.#document, command);
    if (operation.errors.length > 0) {
      for (const error of operation.errors) {
        this.#emitError(error);
      }
      return {
        document: this.getDocument(),
        selection: this.getSelection(),
        changed: false,
        errors: operation.errors,
      };
    }
    if (!operation.changed) {
      return { document: this.getDocument(), selection: this.getSelection(), changed: false };
    }

    this.#document = normalizeDocument(operation.document, this.#registry);
    this.#selection = normalizeSelection(this.#document, this.#selection);
    const validation = validateDocument(this.#document, this.#registry, this.#selection);
    for (const error of validation.errors) {
      this.#emitError(error);
    }
    this.#dirty = true;
    this.#saveState = { ...this.#saveState, dirty: true };
    this.#history.push({
      before,
      after: {
        document: this.getDocument(),
        selection: this.getSelection(),
      },
      commands: [command],
    });
    this.#events.emit({ type: "document:changed", document: this.getDocument() });
    this.#events.emit({ type: "selection:changed", selection: this.getSelection() });
    this.#events.emit({ type: "history:changed", canUndo: this.#history.canUndo, canRedo: this.#history.canRedo });
    return {
      document: this.getDocument(),
      selection: this.getSelection(),
      changed: true,
      ...(validation.errors.length > 0 ? { errors: validation.errors } : {}),
    };
  }

  dispatchBatch(commands: EditorCommand[]): EditorCommandResult {
    if (!Array.isArray(commands)) {
      return this.#errorResult(editorError("command.batch.invalid", "Batch payload must be an array of commands."));
    }
    if (commands.length === 0) {
      return { document: this.getDocument(), selection: this.getSelection(), changed: false };
    }
    for (const command of commands) {
      if (!isEditorCommand(command)) {
        return this.#errorResult(editorError("command.invalid", "Command must be an object with a string type."));
      }
      if (!isKnownCommandType(command.type)) {
        return this.#errorResult(editorError("command.unknown", `Command '${command.type}' is not registered.`));
      }
      if (!this.canDispatch(command)) {
        return this.#errorResult(editorError("command.readOnly", `Command '${command.type}' is not allowed in read-only mode.`));
      }
      if (command.type === "save" || command.type === "request-publish") {
        return this.#errorResult(editorError("command.batch.unsupported", "Save and publish commands cannot be batched."));
      }
    }

    const before = {
      document: this.getDocument(),
      selection: this.getSelection(),
    };
    let nextDocument = this.#document;
    let nextSelection = this.#selection;
    let hasDocumentChange = false;
    let hasSelectionChange = false;
    const errors: EditorError[] = [];

    for (const command of commands) {
      if (!isEditorCommand(command)) {
        errors.push(editorError("command.invalid", "Command must be an object with a string type."));
        break;
      }
      if (!isKnownCommandType(command.type)) {
        errors.push(editorError("command.unknown", `Command '${command.type}' is not registered.`));
        break;
      }
      if (command.type === "set-selection") {
        if (!isRecord(command.payload)) {
          errors.push(editorError("command.payload.invalid", "set-selection payload must be an object."));
          break;
        }
        const payload = command.payload as SetSelectionPayload;
        const normalized = normalizeSelection(nextDocument, payload.selection);
        if (payload.selection !== null && normalized === null) {
          errors.push(editorError("selection.invalid", "Selection must reference valid document positions."));
          break;
        }
        if (!sameSelection(nextSelection, normalized)) {
          hasSelectionChange = true;
          nextSelection = normalized;
        }
        continue;
      }
      const operation = this.#applyMutableCommand(nextDocument, command);
      if (operation.errors.length > 0) {
        errors.push(...operation.errors);
        break;
      }
      if (operation.changed) {
        hasDocumentChange = true;
      }
      nextDocument = normalizeDocument(operation.document, this.#registry);
      nextSelection = normalizeSelection(nextDocument, nextSelection);
    }

    if (errors.length > 0) {
      for (const error of errors) {
        this.#emitError(error);
      }
      return { document: this.getDocument(), selection: this.getSelection(), changed: false, errors };
    }
    if (!hasDocumentChange && !hasSelectionChange) {
      return { document: this.getDocument(), selection: this.getSelection(), changed: false };
    }

    this.#document = nextDocument;
    this.#selection = nextSelection;
    if (hasDocumentChange) {
      this.#dirty = true;
      this.#saveState = { ...this.#saveState, dirty: true };
    }
    const validation = validateDocument(this.#document, this.#registry, this.#selection);
    this.#history.push({
      before,
      after: {
        document: this.getDocument(),
        selection: this.getSelection(),
      },
      commands,
    });
    if (hasDocumentChange) {
      this.#events.emit({ type: "document:changed", document: this.getDocument() });
    }
    this.#events.emit({ type: "selection:changed", selection: this.getSelection() });
    this.#events.emit({ type: "history:changed", canUndo: this.#history.canUndo, canRedo: this.#history.canRedo });
    return {
      document: this.getDocument(),
      selection: this.getSelection(),
      changed: true,
      ...(validation.errors.length > 0 ? { errors: validation.errors } : {}),
    };
  }

  canDispatch(command: EditorCommand): boolean {
    if (!isEditorCommand(command)) {
      return false;
    }
    if (!isKnownCommandType(command.type)) {
      return false;
    }
    if (this.#readOnly && mutableCommandTypes.has(command.type)) {
      return false;
    }
    return true;
  }

  getSelection(): EditorSelection | null {
    return structuredCloneJson(this.#selection);
  }

  setSelection(selection: EditorSelection | null): void {
    const normalized = normalizeSelection(this.#document, selection);
    this.#selection = normalized;
    this.#events.emit({ type: "selection:changed", selection: this.getSelection() });
  }

  undo(): EditorCommandResult {
    const entry = this.#history.undo(this.#document, this.#selection);
    if (!entry) {
      return { document: this.getDocument(), selection: this.getSelection(), changed: false };
    }
    this.#document = entry.before.document;
    this.#selection = entry.before.selection;
    if (!sameDocument(entry.before.document, entry.after.document)) {
      this.#dirty = true;
      this.#saveState = { ...this.#saveState, dirty: true };
      this.#events.emit({ type: "document:changed", document: this.getDocument() });
    }
    this.#events.emit({ type: "selection:changed", selection: this.getSelection() });
    this.#events.emit({ type: "history:changed", canUndo: this.#history.canUndo, canRedo: this.#history.canRedo });
    return { document: this.getDocument(), selection: this.getSelection(), changed: true };
  }

  redo(): EditorCommandResult {
    const entry = this.#history.redo();
    if (!entry) {
      return { document: this.getDocument(), selection: this.getSelection(), changed: false };
    }
    this.#document = entry.after.document;
    this.#selection = entry.after.selection;
    if (!sameDocument(entry.before.document, entry.after.document)) {
      this.#dirty = true;
      this.#saveState = { ...this.#saveState, dirty: true };
      this.#events.emit({ type: "document:changed", document: this.getDocument() });
    }
    this.#events.emit({ type: "selection:changed", selection: this.getSelection() });
    this.#events.emit({ type: "history:changed", canUndo: this.#history.canUndo, canRedo: this.#history.canRedo });
    return { document: this.getDocument(), selection: this.getSelection(), changed: true };
  }

  save(context: SaveContext = { reason: "manual" }): SaveRequest {
    const request = createSaveRequest(this.#document, this.#registry, { ...this.#saveState, dirty: this.#dirty }, context);
    const validation = validateDocument(request.document, this.#registry, this.#selection);
    for (const error of validation.errors) {
      this.#emitError(error);
    }
    this.#saveState = request.state;
    this.#events.emit({ type: "save:requested", request });
    return request;
  }

  requestPublish(context: PublishContext = { reason: "manual" }): PublishRequest {
    const request = createPublishRequest(this.#document, this.#registry, context);
    this.#events.emit({ type: "publish:requested", request });
    return request;
  }

  subscribe(listener: EditorEventListener): Unsubscribe {
    return this.#events.subscribe(listener);
  }

  destroy(): void {
    this.#events.clear();
  }

  #dispatchSelection(command: EditorCommand<SetSelectionPayload>): EditorCommandResult {
    const selection = command.payload.selection;
    const normalized = normalizeSelection(this.#document, selection);
    if (selection !== null && normalized === null) {
      return this.#errorResult(editorError("selection.invalid", "Selection must reference valid document positions."));
    }
    if (sameSelection(this.#selection, normalized)) {
      return { document: this.getDocument(), selection: this.getSelection(), changed: false };
    }
    const before = {
      document: this.getDocument(),
      selection: this.getSelection(),
    };
    this.#selection = normalized;
    this.#history.push({
      before,
      after: {
        document: this.getDocument(),
        selection: this.getSelection(),
      },
      commands: [command],
    });
    this.#events.emit({ type: "selection:changed", selection: this.getSelection() });
    this.#events.emit({ type: "history:changed", canUndo: this.#history.canUndo, canRedo: this.#history.canRedo });
    return { document: this.getDocument(), selection: this.getSelection(), changed: true };
  }

  #applyMutableCommand(document: EditorDocument, command: EditorCommand): { document: EditorDocument; changed: boolean; errors: EditorError[] } {
    if (!isRecord(command.payload)) {
      return {
        document,
        changed: false,
        errors: [editorError("command.payload.invalid", `Command '${command.type}' payload must be an object.`)],
      };
    }
    switch (command.type as MutableCommandType) {
      case "insert-block":
        return insertBlock(document, command.payload as InsertBlockPayload, this.#registry);
      case "delete-block":
        return deleteBlock(document, command.payload as DeleteBlockPayload);
      case "move-block":
        return moveBlock(document, command.payload as MoveBlockPayload, this.#registry);
      case "update-block":
        return updateBlock(document, command.payload as UpdateBlockPayload, this.#registry);
      case "split-block":
        return splitBlock(document, command.payload as SplitBlockPayload, this.#registry);
      case "merge-block":
        return mergeBlock(document, command.payload as MergeBlockPayload, this.#registry);
      case "set-document-meta":
        return setDocumentMeta(document, command.payload as SetDocumentMetaPayload);
      default:
        return {
          document,
          changed: false,
          errors: [editorError("command.unknown", `Command '${command.type}' is not registered.`)],
        };
    }
  }

  #errorResult(error: EditorError): EditorCommandResult {
    this.#emitError(error);
    return {
      document: this.getDocument(),
      selection: this.getSelection(),
      changed: false,
      errors: [error],
    };
  }

  #emitError(error: EditorError): void {
    this.#events.emit({ type: "error", error });
  }
}

export function createEditor(config: EditorConfig = {}): EditorController {
  return new HeadlessEditorController(config);
}

function structuredCloneJson<T>(value: T): T {
  return value === undefined ? value : JSON.parse(JSON.stringify(value)) as T;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function sameDocument(left: EditorDocument, right: EditorDocument): boolean {
  return JSON.stringify(left) === JSON.stringify(right);
}

function sameSelection(left: EditorSelection | null, right: EditorSelection | null): boolean {
  return JSON.stringify(left) === JSON.stringify(right);
}

function isEditorCommand(value: unknown): value is EditorCommand {
  return isRecord(value) && typeof value.type === "string" && "payload" in value;
}

function isKnownCommandType(type: string): boolean {
  return mutableCommandTypes.has(type)
    || type === "set-selection"
    || type === "save"
    || type === "request-publish";
}
